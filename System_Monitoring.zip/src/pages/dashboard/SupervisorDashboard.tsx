import React from 'react';
import { Users, ClipboardList, Calendar } from 'lucide-react';

const SupervisorDashboard: React.FC = () => {
  const stats = [
    { title: 'Active Internees', value: '12', icon: Users, color: 'bg-blue-500' },
    { title: 'Pending Tasks', value: '8', icon: ClipboardList, color: 'bg-yellow-500' },
    { title: 'Today\'s Attendance', value: '95%', icon: Calendar, color: 'bg-green-500' },
  ];

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold text-gray-900">Supervisor Dashboard</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {stats.map((stat) => (
          <div key={stat.title} className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <div className={`${stat.color} p-3 rounded-lg`}>
                <stat.icon className="h-6 w-6 text-white" />
              </div>
              <div className="ml-4">
                <h2 className="text-sm font-medium text-gray-500">{stat.title}</h2>
                <p className="text-2xl font-semibold text-gray-900">{stat.value}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-lg font-medium text-gray-900 mb-4">Recent Tasks</h2>
          <div className="space-y-4">
            {/* Task items would go here */}
            <p className="text-gray-600">No recent tasks</p>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-lg font-medium text-gray-900 mb-4">Internee Performance</h2>
          <div className="space-y-4">
            {/* Performance metrics would go here */}
            <p className="text-gray-600">No performance data available</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SupervisorDashboard;
