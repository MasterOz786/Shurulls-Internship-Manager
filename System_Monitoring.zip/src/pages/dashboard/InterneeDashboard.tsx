import React from 'react';
import { Outlet, Navigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

const InterneeDashboard: React.FC = () => {
  const { user } = useAuth();

  if (!user || user.role !== 'internee') {
    return <Navigate to="/login" replace />;
  }

  return (
    <div>
      <Outlet />
    </div>
  );
};

export default InterneeDashboard;
