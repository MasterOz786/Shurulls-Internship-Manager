import React, { useState, useEffect } from 'react';
import { FileText, CheckCircle, Clock } from 'lucide-react';

interface Submission {
  _id: string;
  task: {
    title: string;
    description: string;
  };
  fileUrl: string;
  status: string;
  submittedAt: string;
  feedback?: string;
}

const Submissions: React.FC = () => {
  const [submissions, setSubmissions] = useState<Submission[]>([]);

  useEffect(() => {
    fetchSubmissions();
  }, []);

  const fetchSubmissions = async () => {
    try {
      const response = await fetch('/api/tasks/submissions');
      const data = await response.json();
      setSubmissions(data);
    } catch (error) {
      console.error('Failed to fetch submissions', error);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'rejected': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold text-gray-900">My Submissions</h1>

      {submissions.length === 0 ? (
        <div className="bg-white shadow rounded-lg p-6 text-center">
          <FileText className="mx-auto h-12 w-12 text-gray-400 mb-4" />
          <p className="text-gray-500">No submissions yet</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {submissions.map((submission) => (
            <div 
              key={submission._id} 
              className="bg-white shadow rounded-lg p-6 space-y-4"
            >
              <div className="flex justify-between items-center">
                <h2 className="text-lg font-semibold">
                  {submission.task.title}
                </h2>
                <span 
                  className={`px-2 py-1 rounded-full text-xs uppercase ${getStatusColor(submission.status)}`}
                >
                  {submission.status}
                </span>
              </div>

              <p className="text-gray-600 text-sm">
                {submission.task.description}
              </p>

              <div className="flex items-center text-sm text-gray-500">
                <Clock className="mr-2 h-4 w-4" />
                Submitted: {new Date(submission.submittedAt).toLocaleString()}
              </div>

              <div className="flex items-center space-x-2">
                <a 
                  href={submission.fileUrl} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex items-center text-indigo-600 hover:text-indigo-800"
                >
                  <FileText className="mr-2 h-4 w-4" />
                  View Submission
                </a>
              </div>

              {submission.feedback && (
                <div className="bg-gray-100 p-3 rounded-md">
                  <h3 className="font-medium mb-2">Feedback</h3>
                  <p className="text-sm text-gray-700">{submission.feedback}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Submissions;
