import React, { useState, useEffect } from 'react';
import { MessageCircle, CheckCircle } from 'lucide-react';

interface Feedback {
  _id: string;
  type: string;
  content: string;
  rating?: number;
  from: { name: string };
  to: { name: string };
  status: string;
  createdAt: string;
}

const FeedbackList: React.FC = () => {
  const [feedbacks, setFeedbacks] = useState<Feedback[]>([]);
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    fetchFeedbacks();
  }, [filter]);

  const fetchFeedbacks = async () => {
    try {
      const response = await fetch(`/api/feedback?type=${filter === 'all' ? '' : filter}`);
      const data = await response.json();
      setFeedbacks(data);
    } catch (error) {
      console.error('Failed to fetch feedbacks', error);
    }
  };

  const resolveFeedback = async (feedbackId: string) => {
    try {
      await fetch(`/api/feedback/${feedbackId}/resolve`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'resolved' })
      });
      fetchFeedbacks();
    } catch (error) {
      console.error('Failed to resolve feedback', error);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-semibold text-gray-900">Feedback</h1>
        <div className="space-x-2">
          {['all', 'task_feedback', 'clarification_request', 'end_of_internship'].map((type) => (
            <button 
              key={type}
              onClick={() => setFilter(type)}
              className={`px-4 py-2 rounded ${
                filter === type 
                  ? 'bg-indigo-500 text-white' 
                  : 'bg-gray-200 text-gray-800'
              }`}
            >
              {type.replace('_', ' ')}
            </button>
          ))}
        </div>
      </div>

      {feedbacks.length === 0 ? (
        <div className="bg-white shadow rounded-lg p-6 text-center">
          <MessageCircle className="mx-auto h-12 w-12 text-gray-400 mb-4" />
          <p className="text-gray-500">No feedback available</p>
        </div>
      ) : (
        <div className="space-y-4">
          {feedbacks.map((feedback) => (
            <div 
              key={feedback._id} 
              className="bg-white shadow rounded-lg p-6 space-y-4"
            >
              <div className="flex justify-between items-center">
                <div>
                  <h2 className="text-lg font-semibold capitalize">
                    {feedback.type.replace('_', ' ')}
                  </h2>
                  <p className="text-sm text-gray-500">
                    From: {feedback.from.name} | To: {feedback.to.name}
                  </p>
                </div>
                <span 
                  className={`px-2 py-1 rounded-full text-xs uppercase ${
                    feedback.status === 'resolved' 
                      ? 'bg-green-100 text-green-800' 
                      : 'bg-yellow-100 text-yellow-800'
                  }`}
                >
                  {feedback.status}
                </span>
              </div>

              <p className="text-gray-600">{feedback.content}</p>

              {feedback.rating && (
                <div className="flex items-center space-x-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <span 
                      key={star} 
                      className={`text-2xl ${
                        star <= feedback.rating! ? 'text-yellow-500' : 'text-gray-300'
                      }`}
                    >
                      ★
                    </span>
                  ))}
                </div>
              )}

              <div className="flex items-center text-sm text-gray-500">
                <span>{new Date(feedback.createdAt).toLocaleString()}</span>
                {feedback.status !== 'resolved' && (
                  <button 
                    onClick={() => resolveFeedback(feedback._id)}
                    className="ml-auto flex items-center text-green-500 hover:text-green-700"
                  >
                    <CheckCircle className="mr-2 h-4 w-4" />
                    Mark as Resolved
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default FeedbackList;
