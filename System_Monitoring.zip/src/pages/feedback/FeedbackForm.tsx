import React, { useState } from 'react';
import { Star, Send } from 'lucide-react';

interface FeedbackFormProps {
  taskId?: string;
  recipientId: string;
  type: 'task_feedback' | 'clarification_request' | 'end_of_internship';
}

const FeedbackForm: React.FC<FeedbackFormProps> = ({ 
  taskId, 
  recipientId, 
  type 
}) => {
  const [content, setContent] = useState('');
  const [rating, setRating] = useState(0);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      const response = await fetch('/api/feedback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          task: taskId,
          to: recipientId,
          type,
          content,
          rating
        })
      });

      const data = await response.json();
      // Reset form or show success message
      setContent('');
      setRating(0);
    } catch (error) {
      console.error('Failed to submit feedback', error);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {type !== 'clarification_request' && (
        <div className="flex items-center space-x-2">
          {[1, 2, 3, 4, 5].map((star) => (
            <Star 
              key={star}
              className={`h-6 w-6 cursor-pointer ${
                star <= rating ? 'text-yellow-500' : 'text-gray-300'
              }`}
              onClick={() => setRating(star)}
            />
          ))}
        </div>
      )}

      <textarea
        value={content}
        onChange={(e) => setContent(e.target.value)}
        placeholder={
          type === 'task_feedback' 
            ? 'Provide feedback on the task' 
            : type === 'clarification_request'
            ? 'Ask for clarification'
            : 'End of internship feedback'
        }
        className="w-full border rounded-md p-2"
        rows={4}
        required
      />

      <button 
        type="submit" 
        className="flex items-center bg-indigo-500 text-white px-4 py-2 rounded-md hover:bg-indigo-600"
      >
        <Send className="mr-2 h-5 w-5" /> Submit Feedback
      </button>
    </form>
  );
};

export default FeedbackForm;
