export type Role = 'admin' | 'supervisor' | 'internee';

export interface User {
  id: string;
  email: string;
  name: string;
  role: Role;
  department?: string;
  contactInfo?: {
    phone?: string;
    address?: string;
  };
  createdAt: Date;
  updatedAt: Date;
}
