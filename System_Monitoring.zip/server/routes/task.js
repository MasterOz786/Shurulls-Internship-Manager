import express from 'express';
import { verifyToken, requireRole } from '../middleware/auth.js';
import * as taskController from '../controllers/taskController.js';
import multer from 'multer';

const router = express.Router();
const upload = multer({ dest: 'uploads/' });

router.post('/', verifyToken, requireRole('admin', 'supervisor'), taskController.createTask);
router.get('/', verifyToken, taskController.getAllTasks);
router.get('/:id', verifyToken, taskController.getTask);
router.put('/:id', verifyToken, requireRole('admin', 'supervisor'), taskController.updateTask);
router.delete('/:id', verifyToken, requireRole('admin', 'supervisor'), taskController.deleteTask);
router.post('/:id/comment', verifyToken, taskController.addComment);
router.post('/:id/submit', verifyToken, upload.single('file'), taskController.submitDeliverable);
router.put('/:id/status', verifyToken, taskController.updateTaskStatus);
router.get('/submissions', verifyToken, taskController.getInterneeSubmissions);

export default router;
