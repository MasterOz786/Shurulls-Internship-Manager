import express from 'express';
import { verifyToken, requireRole } from '../middleware/auth.js';
import * as userController from '../controllers/userController.js';

const router = express.Router();

router.put('/:id', verifyToken, userController.updateUserProfile);

export default router;
