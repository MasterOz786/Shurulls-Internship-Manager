import express from 'express';
import { verifyToken, requireRole } from '../middleware/auth.js';
import * as certificateController from '../controllers/certificateController.js';
import { catchAsync } from '../utils/catchAsync.js';

const router = express.Router();

router.post('/', 
  verifyToken, 
  requireRole('supervisor', 'admin'), 
  catchAsync(certificateController.generateCertificate)
);

router.put('/:certificateId/approve', 
  verifyToken, 
  requireRole('supervisor', 'admin'), 
  catchAsync(certificateController.approveCertificate)
);

router.get('/validate/:validationCode', 
  catchAsync(certificateController.validateCertificate)
);

router.get('/my-certificates', 
  verifyToken, 
  catchAsync(certificateController.getInternCertificates)
);

export default router;
