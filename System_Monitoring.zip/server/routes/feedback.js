import express from 'express';
import { verifyToken, requireRole } from '../middleware/auth.js';
import * as feedbackController from '../controllers/feedbackController.js';
import { catchAsync } from '../utils/catchAsync.js';

const router = express.Router();

router.post('/', 
  verifyToken, 
  catchAsync(feedbackController.createFeedback)
);

router.get('/', 
  verifyToken, 
  catchAsync(feedbackController.getFeedbackForUser)
);

router.put('/:feedbackId/resolve', 
  verifyToken, 
  catchAsync(feedbackController.resolveFeedback)
);

router.post('/end-of-internship', 
  verifyToken, 
  catchAsync(feedbackController.createEndOfInternshipFeedback)
);

export default router;
