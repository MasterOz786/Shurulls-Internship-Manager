import express from 'express';
import { verifyToken, requireRole } from '../middleware/auth.js';
import * as performanceController from '../controllers/performanceController.js';

const router = express.Router();

router.post('/', verifyToken, requireRole('supervisor'), performanceController.createEvaluation);
router.get('/:userId', verifyToken, requireRole('supervisor', 'admin'), performanceController.getEvaluations);
router.get('/summary/:departmentId', verifyToken, requireRole('supervisor', 'admin'), performanceController.getSummary);

export default router;
