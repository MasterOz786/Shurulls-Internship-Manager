import mongoose from 'mongoose';

const WorkshopAttendanceSchema = new mongoose.Schema({
  workshop: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Workshop',
    required: true
  },
  internee: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  checkInTime: {
    type: Date
  },
  status: {
    type: String,
    enum: ['registered', 'attended', 'absent'],
    default: 'registered'
  }
}, { timestamps: true });

export default mongoose.model('WorkshopAttendance', WorkshopAttendanceSchema);
