import Certificate from '../models/Certificate.js';
import { v4 as uuidv4 } from 'uuid';
import { sendNotification } from '../services/notificationService.js';

export const generateCertificate = async (req, res) => {
  const { interneeId, startDate, endDate, department } = req.body;
  const supervisorId = req.user._id;

  const certificate = new Certificate({
    internee: interneeId,
    supervisor: supervisorId,
    department,
    startDate,
    endDate,
    validationCode: uuidv4(),
    status: 'pending'
  });

  await certificate.save();

  // Notify internee about pending certificate
  await sendNotification(interneeId, {
    type: 'certificate_pending',
    message: 'Your internship completion certificate is pending supervisor approval',
    link: `/certificates/${certificate._id}`
  });

  res.status(201).json(certificate);
};

export const approveCertificate = async (req, res) => {
  const { certificateId } = req.params;
  const supervisorId = req.user._id;

  const certificate = await Certificate.findById(certificateId);
  if (!certificate) {
    return res.status(404).json({ message: 'Certificate not found' });
  }

  certificate.status = 'approved';
  certificate.supervisor = supervisorId;
  await certificate.save();

  // Notify internee about approved certificate
  await sendNotification(certificate.internee, {
    type: 'certificate_approved',
    message: 'Your internship completion certificate has been approved!',
    link: `/certificates/${certificateId}`
  });

  res.json(certificate);
};

export const validateCertificate = async (req, res) => {
  const { validationCode } = req.params;

  const certificate = await Certificate.findOne({ 
    validationCode, 
    status: 'approved' 
  }).populate('internee', 'name')
    .populate('department', 'name');

  if (!certificate) {
    return res.status(404).json({ message: 'Invalid or expired certificate' });
  }

  res.json({
    isValid: true,
    internee: certificate.internee.name,
    department: certificate.department.name,
    startDate: certificate.startDate,
    endDate: certificate.endDate
  });
};

export const getInternCertificates = async (req, res) => {
  const interneeId = req.user._id;

  const certificates = await Certificate.find({ 
    internee: interneeId 
  }).populate('department');

  res.json(certificates);
};
