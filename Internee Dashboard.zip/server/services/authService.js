import jwt from 'jsonwebtoken';
import User from '../models/User.js';
import bcrypt from 'bcryptjs';
import { AuthenticationError, DuplicateError, ValidationError, UnauthorizedError } from '../utils/errors.js';

export class AuthService {
  static generateToken(user) {
    return jwt.sign(
      { 
        id: user._id, 
        email: user.email, 
        role: user.role 
      },
      process.env.JWT_SECRET,
      { expiresIn: '24h' }
    );
  }

  static async login(email, password) {
    const user = await User.findOne({ email, isActive: true });
    if (!user || !(await bcrypt.compare(password, user.password))) {
      throw new UnauthorizedError('Invalid credentials');
    }

    const token = this.generateToken(user);
    const userResponse = this.createUserResponse(user);

    return { user: userResponse, token };
  }

  static async register(userData) {
    try {
      const existingUser = await User.findOne({ email: userData.email });
      if (existingUser) {
        throw new DuplicateError('Email already registered');
      }

      const user = await User.create(userData);
      const token = this.generateToken(user);
      const userResponse = this.createUserResponse(user);

      return { user: userResponse, token };
    } catch (error) {
      console.error("Error during registration:", error); 
      if (error.code === 11000) { // Duplicate key error from MongoDB
        throw new DuplicateError('Email already registered');
      } else if (error.name === 'ValidationError') {
        throw new ValidationError(error.message); //Re-throwing with custom error
      } else {
        throw new Error('An error occurred while creating the user.'); //Generic error
      }
    }
  }

  static async validateSession(userId) {
    const user = await User.findOne({ _id: userId, isActive: true });
    if (!user) {
      throw new UnauthorizedError('Session invalid');
    }
    return user;
  }

  static createUserResponse(user) {
    return {
      id: user._id,
      name: user.name,
      email: user.email,
      role: user.role,
      department: user.department,
      contactInfo: user.contactInfo
    };
  }
}
