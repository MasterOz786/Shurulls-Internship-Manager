import Notification from '../models/Notification.js';
import User from '../models/User.js';
import nodemailer from 'nodemailer';

// Configure email transporter
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: process.env.SMTP_PORT,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS
  }
});

export const sendNotification = async (userId, notificationData) => {
  // Create database notification
  const notification = new Notification({
    user: userId,
    ...notificationData
  });
  await notification.save();

  // Fetch user details for email
  const user = await User.findById(userId);

  // Send email notification
  await sendEmailNotification(user.email, notificationData);

  return notification;
};

export const sendEmailNotification = async (email, notificationData) => {
  try {
    await transporter.sendMail({
      from: process.env.EMAIL_FROM,
      to: email,
      subject: getSubjectForNotificationType(notificationData.type),
      html: generateEmailTemplate(notificationData)
    });
  } catch (error) {
    console.error('Email notification failed:', error);
  }
};

const getSubjectForNotificationType = (type) => {
  const subjects = {
    'workshop_created': 'New Workshop Available',
    'workshop_registration': 'Workshop Registration Confirmation',
    'task_assigned': 'New Task Assigned',
    'task_deadline_approaching': 'Task Deadline Approaching',
    'certificate_pending': 'Certificate Pending Approval',
    'certificate_approved': 'Certificate Approved'
  };
  return subjects[type] || 'Internship Management System Notification';
};

const generateEmailTemplate = (notificationData) => {
  return `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2>Internship Management System</h2>
      <p>${notificationData.message}</p>
      ${notificationData.link ? 
        `<a href="${process.env.CLIENT_URL}${notificationData.link}">View Details</a>` : 
        ''
      }
    </div>
  `;
};

export const getNotificationsForUser = async (userId) => {
  return await Notification.find({ user: userId })
    .sort({ createdAt: -1 })
    .limit(20);
};
