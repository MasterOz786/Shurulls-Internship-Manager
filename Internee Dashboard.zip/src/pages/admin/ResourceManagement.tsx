import React from 'react';
import { Monitor, Cpu, BookOpen, Users } from 'lucide-react';

const ResourceManagement: React.FC = () => {
  const resources = [
    {
      title: 'Workstations',
      total: 50,
      allocated: 35,
      icon: Monitor,
      color: 'bg-blue-500',
    },
    {
      title: 'Training Rooms',
      total: 10,
      allocated: 6,
      icon: BookOpen,
      color: 'bg-green-500',
    },
    {
      title: 'Lab Equipment',
      total: 100,
      allocated: 75,
      icon: Cpu,
      color: 'bg-purple-500',
    },
    {
      title: 'Meeting Rooms',
      total: 8,
      allocated: 4,
      icon: Users,
      color: 'bg-yellow-500',
    },
  ];

  return (
    <div className="space-y-6 p-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-semibold text-gray-900">Resource Management</h1>
        <button className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700">
          Add Resource
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {resources.map((resource) => (
          <div key={resource.title} className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <div className={`${resource.color} p-3 rounded-lg`}>
                <resource.icon className="h-6 w-6 text-white" />
              </div>
              <div className="ml-4">
                <h2 className="text-sm font-medium text-gray-500">{resource.title}</h2>
                <p className="text-2xl font-semibold text-gray-900">
                  {resource.allocated}/{resource.total}
                </p>
              </div>
            </div>
            <div className="mt-4">
              <div className="relative pt-1">
                <div className="overflow-hidden h-2 text-xs flex rounded bg-gray-200">
                  <div
                    style={{ width: `${(resource.allocated / resource.total) * 100}%` }}
                    className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-indigo-500"
                  />
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-lg font-medium text-gray-900 mb-4">Resource Allocation</h2>
          <div className="space-y-4">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Resource
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Assigned To
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    Workstation #12
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    John Doe
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                      Active
                    </span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-lg font-medium text-gray-900 mb-4">Resource Requests</h2>
          <div className="space-y-4">
            <div className="border rounded-lg p-4">
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-sm font-medium text-gray-900">Training Room Request</p>
                  <p className="text-sm text-gray-500">Requested by: Jane Smith</p>
                </div>
                <div className="flex space-x-2">
                  <button className="px-3 py-1 bg-green-500 text-white rounded-md hover:bg-green-600">
                    Approve
                  </button>
                  <button className="px-3 py-1 bg-red-500 text-white rounded-md hover:bg-red-600">
                    Deny
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ResourceManagement;
