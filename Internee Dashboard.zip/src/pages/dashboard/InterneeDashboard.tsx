import React from 'react';
import { Outlet } from 'react-router-dom';
import {
  LayoutDashboard,
  Users,
  BookOpen,
  Settings,
  Activity,
  Server,
  Database,
  AlertTriangle,
  ClipboardList,
  Calendar,
  UserCircle,
  Laptop,
  Upload,
  CheckSquare,
  MessageCircle,
  FileText,
  QrCode,
  LogIn,
  LogOut,
  Bell,
  Plus,
  Star,
  Send,
  MapPin,
  Clock
} from 'lucide-react';

const InterneeDashboard: React.FC = () => {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-semibold text-gray-900 mb-4">Internee Dashboard</h1>
      <Outlet />
    </div>
  );
};

export default InterneeDashboard;
