import mongoose from 'mongoose';
import QRCode from 'qrcode';

const CertificateSchema = new mongoose.Schema({
  internee: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  supervisor: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  department: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Department'
  },
  startDate: {
    type: Date,
    required: true
  },
  endDate: {
    type: Date,
    required: true
  },
  qrCode: {
    type: String
  },
  status: {
    type: String,
    enum: ['draft', 'pending', 'approved', 'issued'],
    default: 'draft'
  },
  validationCode: {
    type: String,
    unique: true
  }
}, { timestamps: true });

CertificateSchema.pre('save', async function(next) {
  if (!this.qrCode && this.validationCode) {
    const qrCodeUrl = `https://yourdomain.com/validate/${this.validationCode}`;
    this.qrCode = await QRCode.toDataURL(qrCodeUrl);
  }
  next();
});

export default mongoose.model('Certificate', CertificateSchema);
