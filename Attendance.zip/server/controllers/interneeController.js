import Task from '../models/Task.js';

export const getDashboardCounts = async (req, res) => {
  try {
    const myTasksCount = await Task.countDocuments({ assignedTo: req.user._id });
    const upcomingDeadlinesCount = await Task.countDocuments({ 
      assignedTo: req.user._id, 
      deadline: { $gte: new Date() } 
    });
    res.json({ myTasksCount, upcomingDeadlinesCount });
  } catch (error) {
    console.error('Error fetching dashboard counts:', error);
    res.status(500).json({ message: 'Failed to fetch dashboard counts' });
  }
};
