import User from '../models/User.js';
import Department from '../models/Department.js';
import Task from '../models/Task.js';

export const getDashboardStats = async (req, res) => {
  try {
    const totalUsers = await User.countDocuments();
    const totalDepartments = await Department.countDocuments();
    const activeInternships = await Task.countDocuments({ status: 'active' });
    res.json({ totalUsers, totalDepartments, activeInternships });
  } catch (error) {
    console.error('Error fetching dashboard stats:', error);
    res.status(500).json({ message: 'Failed to fetch dashboard stats' });
  }
};

export const getRecentActivities = async (req, res) => {
  try {
    // Replace this with your actual recent activity fetching logic
    const recentActivities = [
      { id: 1, description: 'User John Doe registered for workshop' },
      { id: 2, description: 'Task "Project X" completed by Jane Doe' },
      { id: 3, description: 'New resource request submitted' }
    ];
    res.json(recentActivities);
  } catch (error) {
    console.error('Error fetching recent activities:', error);
    res.status(500).json({ message: 'Failed to fetch recent activities' });
  }
};
