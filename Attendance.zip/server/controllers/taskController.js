// ... (Existing code)

export const getTaskCounts = async (req, res) => {
  try {
    const pendingCount = await Task.countDocuments({ status: 'pending' });
    const completedCount = await Task.countDocuments({ status: 'completed' });
    res.json({ pending: pendingCount, completed: completedCount });
  } catch (error) {
    console.error('Error fetching task counts:', error);
    res.status(500).json({ message: 'Failed to fetch task counts' });
  }
};
