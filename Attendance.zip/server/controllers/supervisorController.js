import User from '../models/User.js';
import Task from '../models/Task.js';
import Attendance from '../models/Attendance.js';

export const getDashboardStats = async (req, res) => {
  try {
    const activeInternees = await User.countDocuments({ role: 'internee', isActive: true });
    const todaysAttendance = await Attendance.aggregate([
      { $match: { date: new Date().toISOString().split('T')[0] } },
      { $group: { _id: null, count: { $sum: 1 } } }
    ]);
    res.json({ activeInternees, todaysAttendance: todaysAttendance.length > 0 ? todaysAttendance[0].count : 0 });
  } catch (error) {
    console.error('Error fetching dashboard stats:', error);
    res.status(500).json({ message: 'Failed to fetch dashboard stats' });
  }
};

export const getRecentActivities = async (req, res) => {
  try {
    // Replace this with your actual recent activity fetching logic
    const recentActivities = [
      { id: 1, description: 'Internee John Doe submitted task "Project X"' },
      { id: 2, description: 'Task "Project Y" deadline approaching' },
      { id: 3, description: 'Resource "Laptop 123" usage increased' }
    ];
    res.json(recentActivities);
  } catch (error) {
    console.error('Error fetching recent activities:', error);
    res.status(500).json({ message: 'Failed to fetch recent activities' });
  }
};
