import express from 'express';
import { verifyToken, requireRole } from '../middleware/auth.js';
import * as interneeController from '../controllers/interneeController.js';

const router = express.Router();

router.get('/dashboard/counts', verifyToken, requireRole('internee'), interneeController.getDashboardCounts);

export default router;
