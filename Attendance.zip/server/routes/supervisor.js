import express from 'express';
import { verifyToken, requireRole } from '../middleware/auth.js';
import * as supervisorController from '../controllers/supervisorController.js';

const router = express.Router();

router.get('/dashboard/stats', verifyToken, requireRole('supervisor'), supervisorController.getDashboardStats);
router.get('/recent-activities', verifyToken, requireRole('supervisor'), supervisorController.getRecentActivities);

export default router;
