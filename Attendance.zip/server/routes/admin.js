import express from 'express';
import { verifyToken, requireRole } from '../middleware/auth.js';
import * as monitoringController from '../controllers/monitoringController.js';
import * as resourceController from '../controllers/resourceController.js';
import * as adminController from '../controllers/adminController.js';

const router = express.Router();

// Monitoring routes
router.get('/system/status', 
  verifyToken, 
  requireRole('admin'), 
  monitoringController.getSystemStatus
);

router.get('/system/metrics', 
  verifyToken, 
  requireRole('admin'), 
  monitoringController.getSystemMetrics
);

router.get('/system/logs', 
  verifyToken, 
  requireRole('admin'), 
  monitoringController.getSystemLogs
);

// Resource management routes
router.get('/resources', 
  verifyToken, 
  requireRole('admin'), 
  resourceController.getAllResources
);

router.post('/resources/allocate', 
  verifyToken, 
  requireRole('admin'), 
  resourceController.allocateResource
);

router.post('/resources/:resourceId/release', 
  verifyToken, 
  requireRole('admin'), 
  resourceController.releaseResource
);

router.get('/resources/utilization', 
  verifyToken, 
  requireRole('admin'), 
  resourceController.getResourceUtilization
);

router.get('/dashboard/stats', verifyToken, requireRole('admin'), adminController.getDashboardStats);
router.get('/recent-activities', verifyToken, requireRole('admin'), adminController.getRecentActivities);

export default router;
