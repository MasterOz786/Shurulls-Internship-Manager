import React, { useState, useEffect } from 'react';
import { Clock, Calendar, CheckCircle, Loader2 } from 'lucide-react';
import { CircularProgress } from '@mui/material';

interface AttendanceRecord {
  date: string;
  checkInTime: string;
  checkOutTime: string;
  status: string;
  workHours: number;
}

const InterneeAttendance: React.FC = () => {
  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>([]);
  const [canCheckIn, setCanCheckIn] = useState(true);
  const [canCheckOut, setCanCheckOut] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchAttendanceRecords();
    checkCheckInStatus();
  }, []);

  const fetchAttendanceRecords = async () => {
    setIsLoading(true);
    try {
      const response = await fetch('http://localhost:3000/api/attendance/user/current');
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data = await response.json();
      setAttendanceRecords(data);
    } catch (error) {
      console.error('Failed to fetch attendance records', error);
    } finally {
      setIsLoading(false);
    }
  };

  const checkCheckInStatus = async () => {
    try {
      const response = await fetch('http://localhost:3000/api/attendance/check-status');
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data = await response.json();
      setCanCheckIn(data.canCheckIn);
      setCanCheckOut(data.canCheckOut);
    } catch (error) {
      console.error('Failed to check check-in status', error);
    }
  };

  const handleCheckIn = async () => {
    try {
      const response = await fetch('http://localhost:3000/api/attendance/check-in', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ location: 'Office' })
      });
      if (!response.ok) {
        const errorData = await response.json();
        console.error('Error checking in:', errorData);
        alert('Check-in failed. Please try again.');
        return;
      }
      fetchAttendanceRecords();
      checkCheckInStatus();
      alert('Checked in successfully!');
    } catch (error) {
      console.error('Check-in failed', error);
      alert('Check-in failed. Please try again.');
    }
  };

  const handleCheckOut = async () => {
    try {
      const response = await fetch('http://localhost:3000/api/attendance/check-out', { method: 'POST' });
      if (!response.ok) {
        const errorData = await response.json();
        console.error('Error checking out:', errorData);
        alert('Check-out failed. Please try again.');
        return;
      }
      fetchAttendanceRecords();
      checkCheckInStatus();
      alert('Checked out successfully!');
    } catch (error) {
      console.error('Check-out failed', error);
      alert('Check-out failed. Please try again.');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-semibold text-gray-900">My Attendance</h1>
        <div className="space-x-4">
          <button
            onClick={handleCheckIn}
            disabled={!canCheckIn}
            className={`px-4 py-2 rounded ${
              canCheckIn 
                ? 'bg-green-500 text-white hover:bg-green-600' 
                : 'bg-gray-300 text-gray-500 cursor-not-allowed'
            }`}
          >
            Check In
          </button>
          <button
            onClick={handleCheckOut}
            disabled={!canCheckOut}
            className={`px-4 py-2 rounded ${
              canCheckOut 
                ? 'bg-red-500 text-white hover:bg-red-600' 
                : 'bg-gray-300 text-gray-500 cursor-not-allowed'
            }`}
          >
            Check Out
          </button>
        </div>
      </div>

      {isLoading ? (
        <div className="flex justify-center items-center h-64">
          <CircularProgress />
        </div>
      ) : (
        <div className="bg-white shadow overflow-hidden sm:rounded-lg">
          <div className="px-4 py-5 sm:px-6">
            <h3 className="text-lg leading-6 font-medium text-gray-900">
              Attendance Records
            </h3>
          </div>
          <div className="border-t border-gray-200">
            <dl>
              {attendanceRecords.map((record, index) => (
                <div 
                  key={index} 
                  className={`${
                    index % 2 === 0 ? 'bg-white' : 'bg-gray-50'
                  } px-4 py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6`}
                >
                  <dt className="text-sm font-medium text-gray-500 flex items-center">
                    <Calendar className="h-5 w-5 mr-2 text-blue-500" />
                    {new Date(record.date).toLocaleDateString()}
                  </dt>
                  <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2 flex items-center space-x-4">
                    <div className="flex items-center">
                      <Clock className="h-5 w-5 mr-2 text-green-500" />
                      <span>Check-in: {record.checkInTime ? new Date(record.checkInTime).toLocaleTimeString() : 'N/A'}</span>
                    </div>
                    <div className="flex items-center">
                      <Clock className="h-5 w-5 mr-2 text-red-500" />
                      <span>Check-out: {record.checkOutTime ? new Date(record.checkOutTime).toLocaleTimeString() : 'N/A'}</span>
                    </div>
                    <div className="flex items-center">
                      <CheckCircle className={`h-5 w-5 mr-2 ${
                        record.status === 'present' ? 'text-green-500' : 'text-red-500'
                      }`} />
                      <span>{record.status}</span>
                    </div>
                  </dd>
                </div>
              ))}
            </dl>
          </div>
        </div>
      )}
    </div>
  );
};

export default InterneeAttendance;
