import React, { useState, useEffect } from 'react';
import { 
  ClipboardList, 
  CheckCircle, 
  Clock, 
  Upload, 
  MessageCircle, 
  Loader2 
} from 'lucide-react';
import { CircularProgress } from '@mui/material';
import { Link } from 'react-router-dom';

interface Task {
  _id: string;
  title: string;
  description: string;
  status: string;
  priority: string;
  deadline: string;
  deliverables: any[];
  comments: any[];
}

const MyTasks: React.FC = () => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [deliverableFile, setDeliverableFile] = useState<File | null>(null);
  const [comment, setComment] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchTasks();
  }, []);

  const fetchTasks = async () => {
    setIsLoading(true);
    try {
      const response = await fetch('http://localhost:3000/api/tasks');
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data = await response.json();
      setTasks(data);
    } catch (error) {
      console.error('Failed to fetch tasks', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmitDeliverable = async (taskId: string) => {
    if (!deliverableFile) {
      alert('Please select a file');
      return;
    }

    const formData = new FormData();
    formData.append('file', deliverableFile);
    formData.append('description', 'Task deliverable');

    try {
      const response = await fetch(`http://localhost:3000/api/tasks/${taskId}/submit`, {
        method: 'POST',
        body: formData
      });
      if (!response.ok) {
        const errorData = await response.json();
        console.error('Error submitting deliverable:', errorData);
        alert('Failed to submit deliverable. Please try again.');
        return;
      }
      fetchTasks();
      setDeliverableFile(null);
      alert('Deliverable submitted successfully!');
    } catch (error) {
      console.error('Failed to submit deliverable', error);
      alert('Failed to submit deliverable. Please try again.');
    }
  };

  const handleAddComment = async (taskId: string) => {
    if (!comment.trim()) {
      alert('Comment cannot be empty');
      return;
    }

    try {
      const response = await fetch(`http://localhost:3000/api/tasks/${taskId}/comment`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: comment })
      });
      if (!response.ok) {
        const errorData = await response.json();
        console.error('Error adding comment:', errorData);
        alert('Failed to add comment. Please try again.');
        return;
      }
      fetchTasks();
      setComment('');
      alert('Comment added successfully!');
    } catch (error) {
      console.error('Failed to add comment', error);
      alert('Failed to add comment. Please try again.');
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'low': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      {isLoading ? (
        <div className="flex justify-center items-center h-64">
          <CircularProgress />
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white shadow rounded-lg p-6">
              <h2 className="text-xl font-semibold mb-4 flex items-center">
                <ClipboardList className="mr-2 text-indigo-500" /> My Tasks
              </h2>
              {tasks.length === 0 ? (
                <p className="text-gray-500">No tasks assigned</p>
              ) : (
                <div className="space-y-4">
                  {tasks.map((task) => (
                    <Link to={`/feedback/task/${task._id}`} key={task._id} className="border rounded-lg p-4 hover:bg-gray-50 cursor-pointer">
                      <div className="flex justify-between items-center">
                        <h3 className="font-medium">{task.title}</h3>
                        <span 
                          className={`px-2 py-1 rounded-full text-xs uppercase ${getPriorityColor(task.priority)}`}
                        >
                          {task.priority}
                        </span>
                      </div>
                      <div className="flex items-center text-sm text-gray-500 mt-2">
                        <Clock className="mr-2 h-4 w-4" />
                        Deadline: {new Date(task.deadline).toLocaleDateString()}
                      </div>
                      <div className="flex items-center text-sm text-gray-500 mt-1">
                        <CheckCircle className="mr-2 h-4 w-4" />
                        Status: {task.status}
                      </div>
                    </Link>
                  ))}
                </div>
              )}
            </div>

            {selectedTask && (
              <div className="bg-white shadow rounded-lg p-6">
                <h2 className="text-xl font-semibold mb-4">{selectedTask.title}</h2>
                <p className="text-gray-600 mb-4">{selectedTask.description}</p>

                <div className="mb-4">
                  <h3 className="font-medium mb-2">Submit Deliverable</h3>
                  <input 
                    type="file" 
                    onChange={(e) => setDeliverableFile(e.target.files?.[0] || null)}
                    className="w-full border rounded-md p-2"
                  />
                  <button 
                    onClick={() => handleSubmitDeliverable(selectedTask._id)}
                    className="mt-2 w-full bg-green-500 text-white py-2 rounded-md hover:bg-green-600 flex items-center justify-center"
                  >
                    <Upload className="mr-2" /> Submit Deliverable
                  </button>
                </div>

                <div>
                  <h3 className="font-medium mb-2">Comments</h3>
                  <div className="space-y-2 max-h-48 overflow-y-auto mb-4">
                    {selectedTask.comments.map((comment, index) => (
                      <div key={index} className="bg-gray-100 p-2 rounded-md">
                        <p className="text-sm">{comment.text}</p>
                        <p className="text-xs text-gray-500">
                          {new Date(comment.createdAt).toLocaleString()}
                        </p>
                      </div>
                    ))}
                  </div>
                  <div className="flex">
                    <input 
                      type="text"
                      value={comment}
                      onChange={(e) => setComment(e.target.value)}
                      placeholder="Add a comment"
                      className="flex-grow border rounded-l-md p-2"
                    />
                    <button 
                      onClick={() => handleAddComment(selectedTask._id)}
                      className="bg-indigo-500 text-white px-4 rounded-r-md hover:bg-indigo-600"
                    >
                      <MessageCircle className="h-5 w-5" />
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
};

export default MyTasks;
