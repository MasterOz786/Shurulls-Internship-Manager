import React, { useState, useEffect } from 'react';
import { FileText, CheckCircle, QrCode, Loader2 } from 'lucide-react';
import { CircularProgress } from '@mui/material';

interface Certificate {
  _id: string;
  department: { name: string };
  startDate: string;
  endDate: string;
  status: string;
  qrCode?: string;
}

const CertificateList: React.FC = () => {
  const [certificates, setCertificates] = useState<Certificate[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchCertificates();
  }, []);

  const fetchCertificates = async () => {
    setIsLoading(true);
    try {
      const response = await fetch('http://localhost:3000/api/certificates/my-certificates');
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data = await response.json();
      setCertificates(data);
    } catch (error) {
      console.error('Failed to fetch certificates', error);
    } finally {
      setIsLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'draft': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold text-gray-900">My Certificates</h1>

      {isLoading ? (
        <div className="flex justify-center items-center h-64">
          <CircularProgress />
        </div>
      ) : (
        <>
          {certificates.length === 0 ? (
            <div className="bg-white shadow rounded-lg p-6 text-center">
              <FileText className="mx-auto h-12 w-12 text-gray-400 mb-4" />
              <p className="text-gray-500">No certificates available</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {certificates.map((certificate) => (
                <div 
                  key={certificate._id} 
                  className="bg-white shadow rounded-lg p-6 space-y-4"
                >
                  <div className="flex justify-between items-center">
                    <h2 className="text-lg font-semibold">
                      Internship Certificate
                    </h2>
                    <span 
                      className={`px-2 py-1 rounded-full text-xs uppercase ${getStatusColor(certificate.status)}`}
                    >
                      {certificate.status}
                    </span>
                  </div>

                  <div className="space-y-2">
                    <p className="text-sm text-gray-600">
                      <strong>Department:</strong> {certificate.department.name}
                    </p>
                    <p className="text-sm text-gray-600">
                      <strong>Period:</strong> {new Date(certificate.startDate).toLocaleDateString()} - {new Date(certificate.endDate).toLocaleDateString()}
                    </p>
                  </div>

                  {certificate.status === 'approved' && certificate.qrCode && (
                    <div className="flex justify-center">
                      <img 
                        src={certificate.qrCode} 
                        alt="Certificate QR Code" 
                        className="w-32 h-32"
                      />
                    </div>
                  )}

                  {certificate.status === 'approved' && (
                    <div className="flex items-center text-sm text-green-600">
                      <CheckCircle className="mr-2 h-5 w-5" />
                      Certificate is valid and ready for download
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default CertificateList;
