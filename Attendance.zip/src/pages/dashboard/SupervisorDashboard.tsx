import React, { useState, useEffect } from 'react';
import { Users, ClipboardList, Calendar, Loader2 } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { BarChart } from '@mui/x-charts/BarChart';
import { CircularProgress } from '@mui/material';

const SupervisorDashboard: React.FC = () => {
  const { user } = useAuth();
  const [pendingTasks, setPendingTasks] = useState(0);
  const [completedTasks, setCompletedTasks] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [activeInternees, setActiveInternees] = useState(0);
  const [todaysAttendance, setTodaysAttendance] = useState(0);
  const [recentActivities, setRecentActivities] = useState([]);

  useEffect(() => {
    fetchTaskCounts();
    fetchDashboardStats();
    fetchRecentActivities();
  }, []);

  const fetchTaskCounts = async () => {
    try {
      const response = await fetch('http://localhost:3000/api/tasks/counts');
      const data = await response.json();
      setPendingTasks(data.pending);
      setCompletedTasks(data.completed);
    } catch (error) {
      console.error('Failed to fetch task counts', error);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchDashboardStats = async () => {
    try {
      const response = await fetch('http://localhost:3000/api/supervisor/dashboard/stats');
      const data = await response.json();
      setActiveInternees(data.activeInternees);
      setTodaysAttendance(data.todaysAttendance);
    } catch (error) {
      console.error('Failed to fetch dashboard stats', error);
    }
  };

  const fetchRecentActivities = async () => {
    try {
      const response = await fetch('http://localhost:3000/api/supervisor/recent-activities');
      const data = await response.json();
      setRecentActivities(data);
    } catch (error) {
      console.error('Failed to fetch recent activities', error);
    }
  };

  const chartData = [
    { label: 'Pending Tasks', value: pendingTasks },
    { label: 'Completed Tasks', value: completedTasks }
  ];

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold text-gray-900">Supervisor Dashboard</h1>

      {isLoading ? (
        <div className="flex justify-center items-center h-64">
          <CircularProgress />
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center mb-4">
                <div className="bg-blue-500 p-3 rounded-lg">
                  <Users className="h-6 w-6 text-white" />
                </div>
                <div className="ml-4">
                  <h2 className="text-sm font-medium text-gray-500">Active Internees</h2>
                  <p className="text-2xl font-semibold text-gray-900">{activeInternees}</p>
                </div>
              </div>
            </div>
            <div className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center mb-4">
                <div className="bg-yellow-500 p-3 rounded-lg">
                  <ClipboardList className="h-6 w-6 text-white" />
                </div>
                <div className="ml-4">
                  <h2 className="text-sm font-medium text-gray-500">Pending Tasks</h2>
                  <p className="text-2xl font-semibold text-gray-900">{pendingTasks}</p>
                </div>
              </div>
            </div>
            <div className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center mb-4">
                <div className="bg-green-500 p-3 rounded-lg">
                  <Calendar className="h-6 w-6 text-white" />
                </div>
                <div className="ml-4">
                  <h2 className="text-sm font-medium text-gray-500">Today's Attendance</h2>
                  <p className="text-2xl font-semibold text-gray-900">{todaysAttendance}%</p>
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-lg font-medium text-gray-900 mb-4">Task Progress</h2>
              <BarChart
                width={500}
                height={300}
                series={chartData}
                xAxis={[{ scale: 'band', dataKey: 'label' }]}
                yAxis={[{ scale: 'linear', dataKey: 'value' }]}
              />
            </div>

            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-lg font-medium text-gray-900 mb-4">Recent Activities</h2>
              <ul className="space-y-2">
                {recentActivities.map((activity) => (
                  <li key={activity.id} className="text-gray-600">
                    {activity.description}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default SupervisorDashboard;
