import React, { useState, useEffect } from 'react';
import { Outlet, Navigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { Clock, ClipboardList, Loader2 } from 'lucide-react';
import { CircularProgress } from '@mui/material';

const InterneeDashboard: React.FC = () => {
  const { user } = useAuth();
  const [myTasksCount, setMyTasksCount] = useState(0);
  const [upcomingDeadlinesCount, setUpcomingDeadlinesCount] = useState(0);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetchDashboardCounts();
  }, []);

  const fetchDashboardCounts = async () => {
    try {
      const response = await fetch('http://localhost:3000/api/internee/dashboard/counts');
      const data = await response.json();
      setMyTasksCount(data.myTasksCount);
      setUpcomingDeadlinesCount(data.upcomingDeadlinesCount);
    } catch (error) {
      console.error('Failed to fetch dashboard counts', error);
    } finally {
      setIsLoading(false);
    }
  };

  if (!user || user.role !== 'internee') {
    return <Navigate to="/login" replace />;
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold text-gray-900">Internee Dashboard</h1>
      {isLoading ? (
        <div className="flex justify-center items-center h-64">
          <CircularProgress />
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center mb-4">
              <div className="bg-blue-500 p-3 rounded-lg">
                <ClipboardList className="h-6 w-6 text-white" />
              </div>
              <div className="ml-4">
                <h2 className="text-sm font-medium text-gray-500">My Tasks</h2>
                <p className="text-2xl font-semibold text-gray-900">{myTasksCount}</p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center mb-4">
              <div className="bg-green-500 p-3 rounded-lg">
                <Clock className="h-6 w-6 text-white" />
              </div>
              <div className="ml-4">
                <h2 className="text-sm font-medium text-gray-500">Upcoming Deadlines</h2>
                <p className="text-2xl font-semibold text-gray-900">{upcomingDeadlinesCount}</p>
              </div>
            </div>
          </div>
        </div>
      )}
      <Outlet />
    </div>
  );
};

export default InterneeDashboard;
