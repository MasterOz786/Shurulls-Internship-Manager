import React, { useState, useEffect } from 'react';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import { Doughnut } from 'react-chartjs-2';
import { Users } from 'lucide-react';

ChartJS.register(ArcElement, Tooltip, Legend);

interface PerformanceSummary {
  userDetails: {
    name: string;
  };
  averageRating: number;
}

const PerformanceManagement: React.FC = () => {
  const [performanceSummary, setPerformanceSummary] = useState<PerformanceSummary[]>([]);
  const [selectedDepartment, setSelectedDepartment] = useState<string | null>(null);

  useEffect(() => {
    fetchPerformanceSummary();
  }, [selectedDepartment]);

  const fetchPerformanceSummary = async () => {
    try {
      const response = await fetch(`/api/performance/summary/${selectedDepartment}`);
      const data = await response.json();
      setPerformanceSummary(data);
    } catch (error) {
      console.error('Failed to fetch performance summary', error);
    }
  };

  const data = {
    labels: performanceSummary.map((summary) => summary.userDetails.name),
    datasets: [
      {
        label: 'Average Rating',
        data: performanceSummary.map((summary) => summary.averageRating),
        backgroundColor: [
          'rgba(255, 99, 132, 0.2)',
          'rgba(54, 162, 235, 0.2)',
          'rgba(255, 206, 86, 0.2)',
          'rgba(75, 192, 192, 0.2)',
          'rgba(153, 102, 255, 0.2)',
          'rgba(255, 159, 64, 0.2)',
        ],
        borderColor: [
          'rgba(255, 99, 132, 1)',
          'rgba(54, 162, 235, 1)',
          'rgba(255, 206, 86, 1)',
          'rgba(75, 192, 192, 1)',
          'rgba(153, 102, 255, 1)',
          'rgba(255, 159, 64, 1)',
        ],
        borderWidth: 1,
      },
    ],
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-semibold text-gray-900">Performance Management</h1>
        <select
          value={selectedDepartment}
          onChange={(e) => setSelectedDepartment(e.target.value)}
          className="border rounded px-2 py-1"
        >
          <option value="">Select Department</option>
          {/* Add department options here */}
        </select>
      </div>

      <div className="bg-white shadow rounded-lg p-6">
        <Doughnut data={data} />
      </div>
    </div>
  );
};

export default PerformanceManagement;
