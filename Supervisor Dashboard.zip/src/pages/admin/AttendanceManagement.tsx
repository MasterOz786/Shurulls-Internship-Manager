import React, { useState, useEffect } from 'react';
import { Calendar, Clock, Users } from 'lucide-react';

interface AttendanceSummary {
  departmentDetails: {
    name: string;
  };
  totalPresent: number;
  totalAbsent: number;
  totalLate: number;
  averageWorkHours: number;
}

const AttendanceManagement: React.FC = () => {
  const [attendanceSummary, setAttendanceSummary] = useState<AttendanceSummary[]>([]);
  const [selectedDepartment, setSelectedDepartment] = useState<string | null>(null);
  const [dateRange, setDateRange] = useState({
    startDate: new Date(new Date().getFullYear(), 0, 1).toISOString().split('T')[0],
    endDate: new Date().toISOString().split('T')[0]
  });

  useEffect(() => {
    fetchAttendanceSummary();
  }, [selectedDepartment, dateRange]);

  const fetchAttendanceSummary = async () => {
    try {
      const params = new URLSearchParams({
        startDate: dateRange.startDate,
        endDate: dateRange.endDate,
        ...(selectedDepartment && { department: selectedDepartment })
      });

      const response = await fetch(`/api/attendance/summary?${params}`);
      const data = await response.json();
      setAttendanceSummary(data);
    } catch (error) {
      console.error('Failed to fetch attendance summary', error);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-semibold text-gray-900">Attendance Management</h1>
        <div className="flex space-x-4">
          <input
            type="date"
            value={dateRange.startDate}
            onChange={(e) => setDateRange(prev => ({ ...prev, startDate: e.target.value }))}
            className="border rounded px-2 py-1"
          />
          <input
            type="date"
            value={dateRange.endDate}
            onChange={(e) => setDateRange(prev => ({ ...prev, endDate: e.target.value }))}
            className="border rounded px-2 py-1"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {attendanceSummary.map((summary) => (
          <div key={summary.departmentDetails.name} className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center mb-4">
              <Users className="h-6 w-6 text-indigo-500 mr-3" />
              <h2 className="text-lg font-semibold text-gray-900">
                {summary.departmentDetails.name}
              </h2>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center">
                <Calendar className="h-5 w-5 text-green-500 mr-2" />
                <div>
                  <p className="text-sm text-gray-500">Present</p>
                  <p className="text-lg font-bold">{summary.totalPresent}</p>
                </div>
              </div>
              <div className="flex items-center">
                <Clock className="h-5 w-5 text-red-500 mr-2" />
                <div>
                  <p className="text-sm text-gray-500">Absent</p>
                  <p className="text-lg font-bold">{summary.totalAbsent}</p>
                </div>
              </div>
              <div className="flex items-center">
                <Clock className="h-5 w-5 text-yellow-500 mr-2" />
                <div>
                  <p className="text-sm text-gray-500">Late</p>
                  <p className="text-lg font-bold">{summary.totalLate}</p>
                </div>
              </div>
              <div className="flex items-center">
                <Clock className="h-5 w-5 text-blue-500 mr-2" />
                <div>
                  <p className="text-sm text-gray-500">Avg Hours</p>
                  <p className="text-lg font-bold">{summary.averageWorkHours.toFixed(2)}</p>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AttendanceManagement;
