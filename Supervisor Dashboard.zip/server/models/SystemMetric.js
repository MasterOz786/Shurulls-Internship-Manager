import mongoose from 'mongoose';

const systemMetricSchema = new mongoose.Schema({
  timestamp: {
    type: Date,
    required: true,
    default: Date.now
  },
  type: {
    type: String,
    required: true,
    enum: ['cpu', 'memory', 'disk', 'network']
  },
  value: {
    type: Number,
    required: true
  },
  metadata: {
    type: Map,
    of: mongoose.Schema.Types.Mixed
  }
}, {
  timestamps: true
});

// Index for efficient querying of recent metrics
systemMetricSchema.index({ timestamp: -1, type: 1 });

export default mongoose.model('SystemMetric', systemMetricSchema);
