import SystemMetric from '../models/SystemMetric.js';
import os from 'os';

export class MonitoringService {
  static async getSystemStatus() {
    const cpus = os.cpus();
    const totalMemory = os.totalmem();
    const freeMemory = os.freemem();
    
    const cpuUsage = process.cpuUsage();
    const memoryUsage = ((totalMemory - freeMemory) / totalMemory) * 100;

    const metric = new SystemMetric({
      type: 'system_status',
      value: {
        cpuUsage: cpuUsage.user / 1000000,
        memoryUsage: memoryUsage,
        uptime: os.uptime(),
        loadAverage: os.loadavg()
      }
    });
    await metric.save();

    return {
      cpuUsage: Math.round(cpuUsage.user / 1000000),
      memoryUsage: Math.round(memoryUsage),
      uptime: os.uptime(),
      activeConnections: await this.getActiveConnections(),
      databaseStatus: await this.checkDatabaseHealth(),
      lastIncident: await this.getLastIncident()
    };
  }

  static async getActiveConnections() {
    // Implementation would depend on your specific server setup
    return 0;
  }

  static async checkDatabaseHealth() {
    try {
      await mongoose.connection.db.admin().ping();
      return 'healthy';
    } catch (error) {
      return 'degraded';
    }
  }

  static async getLastIncident() {
    const lastError = await SystemMetric.findOne({ 
      type: 'error' 
    }).sort({ timestamp: -1 });
    
    return lastError ? lastError.timestamp : null;
  }

  static async getSystemMetrics(type, duration) {
    const startTime = new Date(Date.now() - duration);
    
    return await SystemMetric.find({
      type,
      timestamp: { $gte: startTime }
    }).sort({ timestamp: 1 });
  }
}
