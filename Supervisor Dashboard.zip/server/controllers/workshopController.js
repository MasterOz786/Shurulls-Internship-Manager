import Workshop from '../models/Workshop.js';
import WorkshopAttendance from '../models/WorkshopAttendance.js';
import { NotFoundError, ValidationError } from '../utils/errors.js';
import { sendNotification } from '../services/notificationService.js';

export const createWorkshop = async (req, res) => {
  const { 
    title, 
    description, 
    date, 
    startTime, 
    endTime, 
    location, 
    department, 
    trainer 
  } = req.body;

  const workshop = new Workshop({
    title,
    description,
    date,
    startTime,
    endTime,
    location,
    department,
    trainer
  });

  await workshop.save();

  // Notify internees in the department about the new workshop
  const internees = await User.find({ 
    department: department, 
    role: 'internee' 
  });

  for (let internee of internees) {
    await sendNotification(internee._id, {
      type: 'workshop_created',
      message: `New Workshop: ${title} on ${new Date(date).toLocaleDateString()}`,
      link: `/workshops/${workshop._id}`
    });
  }

  res.status(201).json(workshop);
};

export const registerForWorkshop = async (req, res) => {
  const { workshopId } = req.params;
  const userId = req.user._id;

  const workshop = await Workshop.findById(workshopId);
  if (!workshop) throw new NotFoundError('Workshop not found');

  if (workshop.registeredInternees.includes(userId)) {
    throw new ValidationError('Already registered for this workshop');
  }

  workshop.registeredInternees.push(userId);
  await workshop.save();

  const attendance = new WorkshopAttendance({
    workshop: workshopId,
    internee: userId
  });
  await attendance.save();

  await sendNotification(workshop.trainer, {
    type: 'workshop_registration',
    message: `${req.user.name} registered for ${workshop.title}`,
    link: `/workshops/${workshopId}`
  });

  res.status(200).json(workshop);
};

export const getWorkshops = async (req, res) => {
  const { department, status } = req.query;
  const query = {};

  if (department) query.department = department;
  if (status) query.status = status;

  const workshops = await Workshop.find(query)
    .populate('department')
    .populate('trainer');

  res.json(workshops);
};

export const checkInToWorkshop = async (req, res) => {
  const { workshopId } = req.params;
  const userId = req.user._id;

  const attendance = await WorkshopAttendance.findOne({
    workshop: workshopId,
    internee: userId
  });

  if (!attendance) {
    throw new NotFoundError('Workshop registration not found');
  }

  attendance.checkInTime = new Date();
  attendance.status = 'attended';
  await attendance.save();

  res.json(attendance);
};

export const getWorkshopAttendance = async (req, res) => {
  const { workshopId } = req.params;

  const attendance = await WorkshopAttendance.find({ workshop: workshopId })
    .populate('internee', 'name email');

  res.json(attendance);
};
