import Task from '../models/Task.js';
import { catchAsync } from '../utils/catchAsync.js';
import { NotFoundError } from '../utils/errors.js';
import path from 'path';
import fs from 'fs';

export const createTask = catchAsync(async (req, res) => {
  const task = await Task.create({
    ...req.body,
    assignedBy: req.user.id
  });
  res.status(201).json(task);
});

export const getAllTasks = catchAsync(async (req, res) => {
  let query = {};
  if (req.user.role === 'internee') {
    query.assignedTo = req.user.id;
  } else if (req.user.role === 'supervisor') {
    query.assignedBy = req.user.id;
  }

  const tasks = await Task.find(query)
    .populate('assignedTo', 'name email')
    .populate('assignedBy', 'name email')
    .populate('department', 'name');
  res.json(tasks);
});

export const getTask = catchAsync(async (req, res) => {
  const task = await Task.findById(req.params.id)
    .populate('assignedTo', 'name email')
    .populate('assignedBy', 'name email')
    .populate('department', 'name');
  if (!task) throw new NotFoundError('Task not found');
  res.json(task);
});

export const updateTask = catchAsync(async (req, res) => {
  const task = await Task.findByIdAndUpdate(req.params.id, req.body, { new: true });
  if (!task) throw new NotFoundError('Task not found');
  res.json(task);
});

export const deleteTask = catchAsync(async (req, res) => {
  const task = await Task.findByIdAndDelete(req.params.id);
  if (!task) throw new NotFoundError('Task not found');
  res.status(204).end();
});

export const addComment = catchAsync(async (req, res) => {
  const { text } = req.body;
  const task = await Task.findById(req.params.id);
  if (!task) throw new NotFoundError('Task not found');

  task.comments.push({
    user: req.user.id,
    text
  });
  await task.save();

  res.json(task);
});

export const submitDeliverable = catchAsync(async (req, res) => {
  const task = await Task.findById(req.params.id);
  if (!task) throw new NotFoundError('Task not found');

  // Ensure file was uploaded
  if (!req.file) {
    return res.status(400).json({ message: 'No file uploaded' });
  }

  // Generate a unique filename
  const fileExtension = path.extname(req.file.originalname);
  const filename = `${task._id}_${Date.now()}${fileExtension}`;
  const newPath = path.join('uploads', filename);

  // Move file to uploads directory
  fs.renameSync(req.file.path, newPath);

  // Add deliverable to task
  task.deliverables.push({
    description: req.body.description || 'Task deliverable',
    fileUrl: `/uploads/${filename}`,
    submittedAt: new Date()
  });

  task.status = 'review';
  await task.save();

  res.status(201).json(task);
});

export const updateTaskStatus = catchAsync(async (req, res) => {
  const { status, feedback } = req.body;
  const task = await Task.findById(req.params.id);
  if (!task) throw new NotFoundError('Task not found');

  task.status = status;
  if (feedback) {
    const lastDeliverable = task.deliverables[task.deliverables.length - 1];
    if (lastDeliverable) {
      lastDeliverable.feedback = feedback;
    }
  }
  await task.save();

  res.json(task);
});

export const getInterneeSubmissions = catchAsync(async (req, res) => {
  const submissions = await Task.find({
    assignedTo: req.user.id,
    'deliverables.0': { $exists: true }
  }).select('task deliverables status');

  const formattedSubmissions = submissions.flatMap(task => 
    task.deliverables.map(deliverable => ({
      _id: deliverable._id,
      task: {
        title: task.title,
        description: task.description
      },
      fileUrl: deliverable.fileUrl,
      status: task.status,
      submittedAt: deliverable.submittedAt,
      feedback: deliverable.feedback
    }))
  );

  res.json(formattedSubmissions);
});
