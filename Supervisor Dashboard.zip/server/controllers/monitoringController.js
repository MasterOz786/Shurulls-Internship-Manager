import { MonitoringService } from '../services/monitoringService.js';
import { catchAsync } from '../utils/catchAsync.js';

export const getSystemStatus = catchAsync(async (req, res) => {
  const status = await MonitoringService.getSystemStatus();
  res.json(status);
});

export const getSystemMetrics = catchAsync(async (req, res) => {
  const { type, duration } = req.query;
  const metrics = await MonitoringService.getSystemMetrics(type, parseInt(duration));
  res.json(metrics);
});

export const getSystemLogs = catchAsync(async (req, res) => {
  const { level, limit } = req.query;
  const logs = await MonitoringService.getSystemLogs(level, parseInt(limit));
  res.json(logs);
});
