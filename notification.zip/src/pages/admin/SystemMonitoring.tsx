import React from 'react';
import { Activity, Server, Database, AlertTriangle } from 'lucide-react';
import { ServerStatus } from '../../types/monitoring';

const SystemMonitoring: React.FC = () => {
  const [serverStatus, setServerStatus] = React.useState<ServerStatus>({
    cpuUsage: 0,
    memoryUsage: 0,
    uptime: 0,
    activeConnections: 0,
    databaseStatus: 'healthy',
    lastIncident: null,
  });

  const healthIndicators = [
    {
      title: 'CPU Usage',
      value: `${serverStatus.cpuUsage}%`,
      icon: Activity,
      color: serverStatus.cpuUsage > 80 ? 'bg-red-500' : 'bg-green-500',
    },
    {
      title: 'Memory Usage',
      value: `${serverStatus.memoryUsage}%`,
      icon: Server,
      color: serverStatus.memoryUsage > 80 ? 'bg-red-500' : 'bg-green-500',
    },
    {
      title: 'Database Status',
      value: serverStatus.databaseStatus,
      icon: Database,
      color: serverStatus.databaseStatus === 'healthy' ? 'bg-green-500' : 'bg-red-500',
    },
    {
      title: 'Active Connections',
      value: serverStatus.activeConnections,
      icon: AlertTriangle,
      color: serverStatus.activeConnections > 1000 ? 'bg-yellow-500' : 'bg-green-500',
    },
  ];

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold text-gray-900">System Monitoring</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {healthIndicators.map((indicator) => (
          <div key={indicator.title} className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <div className={`${indicator.color} p-3 rounded-lg`}>
                <indicator.icon className="h-6 w-6 text-white" />
              </div>
              <div className="ml-4">
                <h2 className="text-sm font-medium text-gray-500">{indicator.title}</h2>
                <p className="text-2xl font-semibold text-gray-900">{indicator.value}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-lg font-medium text-gray-900 mb-4">System Logs</h2>
          <div className="space-y-4 max-h-96 overflow-y-auto">
            <pre className="text-sm text-gray-600 whitespace-pre-wrap">
              {/* System logs would be displayed here */}
              No recent system logs
            </pre>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-lg font-medium text-gray-900 mb-4">Error Alerts</h2>
          <div className="space-y-4">
            {/* Error alerts would be displayed here */}
            <p className="text-gray-600">No active alerts</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SystemMonitoring;
