import React, { useState, useEffect } from 'react';
import { Laptop, Printer, Smartphone, BookOpen } from 'lucide-react';

const resourceIcons = {
  laptop: Laptop,
  printer: Printer,
  smartphone: Smartphone,
  book: BookOpen
};

const MyResources: React.FC = () => {
  const [resources, setResources] = useState([]);
  const [newResourceRequest, setNewResourceRequest] = useState({
    resourceType: '',
    details: ''
  });

  useEffect(() => {
    fetchResources();
  }, []);

  const fetchResources = async () => {
    try {
      const response = await fetch('/api/resources/my-resources');
      const data = await response.json();
      setResources(data);
    } catch (error) {
      console.error('Failed to fetch resources', error);
    }
  };

  const handleResourceRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await fetch('/api/resources/request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newResourceRequest)
      });
      const data = await response.json();
      fetchResources();
      setNewResourceRequest({ resourceType: '', details: '' });
    } catch (error) {
      console.error('Failed to request resource', error);
    }
  };

  const handleReturnResource = async (resourceId: string) => {
    try {
      const response = await fetch(`/api/resources/${resourceId}/return`, {
        method: 'PUT'
      });
      const data = await response.json();
      fetchResources();
    } catch (error) {
      console.error('Failed to return resource', error);
    }
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white shadow rounded-lg p-6">
          <h2 className="text-xl font-semibold mb-4">Request New Resource</h2>
          <form onSubmit={handleResourceRequest} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">Resource Type</label>
              <select
                value={newResourceRequest.resourceType}
                onChange={(e) => setNewResourceRequest(prev => ({ 
                  ...prev, 
                  resourceType: e.target.value 
                }))}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm"
                required
              >
                <option value="">Select Resource Type</option>
                <option value="laptop">Laptop</option>
                <option value="printer">Printer</option>
                <option value="smartphone">Smartphone</option>
                <option value="book">Book</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Additional Details</label>
              <textarea
                value={newResourceRequest.details}
                onChange={(e) => setNewResourceRequest(prev => ({ 
                  ...prev, 
                  details: e.target.value 
                }))}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm"
                rows={3}
                placeholder="Provide any specific requirements"
              />
            </div>
            <button 
              type="submit" 
              className="w-full bg-indigo-600 text-white py-2 rounded-md hover:bg-indigo-700"
            >
              Request Resource
            </button>
          </form>
        </div>

        <div className="bg-white shadow rounded-lg p-6">
          <h2 className="text-xl font-semibold mb-4">My Resources</h2>
          {resources.length === 0 ? (
            <p className="text-gray-500">No resources assigned</p>
          ) : (
            <div className="space-y-4">
              {resources.map((resource) => {
                const Icon = resourceIcons[resource.type] || BookOpen;
                return (
                  <div 
                    key={resource._id} 
                    className="flex items-center justify-between border-b pb-3 last:border-b-0"
                  >
                    <div className="flex items-center space-x-4">
                      <Icon className="h-6 w-6 text-indigo-500" />
                      <div>
                        <p className="font-medium capitalize">{resource.type}</p>
                        <p className="text-sm text-gray-500">
                          Status: {resource.status}
                        </p>
                      </div>
                    </div>
                    {resource.status === 'assigned' && (
                      <button 
                        onClick={() => handleReturnResource(resource._id)}
                        className="px-3 py-1 bg-red-500 text-white rounded-md hover:bg-red-600"
                      >
                        Return
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default MyResources;
