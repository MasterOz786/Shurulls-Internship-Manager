import express from 'express';
import { login, register, logout, getSession } from '../controllers/authController.js';
import { verifyToken } from '../middleware/auth.js';

const router = express.Router();

router.post('/login', login);
router.post('/register', register);
router.post('/logout', logout);
router.get('/session', verifyToken, getSession);

export default router;
