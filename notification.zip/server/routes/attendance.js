import express from 'express';
import { verifyToken, requireRole } from '../middleware/auth.js';
import * as attendanceController from '../controllers/attendanceController.js';

const router = express.Router();

router.post('/checkin', verifyToken, attendanceController.checkIn);
router.post('/checkout', verifyToken, attendanceController.checkOut);
router.get('/', verifyToken, requireRole('supervisor', 'admin'), attendanceController.getAttendance);
router.get('/summary', verifyToken, requireRole('supervisor', 'admin'), attendanceController.getAttendanceSummary);

export default router;
