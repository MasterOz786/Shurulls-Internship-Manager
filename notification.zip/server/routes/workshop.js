import express from 'express';
import { verifyToken, requireRole } from '../middleware/auth.js';
import * as workshopController from '../controllers/workshopController.js';
import { catchAsync } from '../utils/catchAsync.js';

const router = express.Router();

router.post('/', 
  verifyToken, 
  requireRole('admin', 'supervisor'), 
  catchAsync(workshopController.createWorkshop)
);

router.get('/', 
  verifyToken, 
  catchAsync(workshopController.getWorkshops)
);

router.post('/:workshopId/register', 
  verifyToken, 
  catchAsync(workshopController.registerForWorkshop)
);

router.post('/:workshopId/checkin', 
  verifyToken, 
  catchAsync(workshopController.checkInToWorkshop)
);

router.get('/:workshopId/attendance', 
  verifyToken, 
  requireRole('admin', 'supervisor'), 
  catchAsync(workshopController.getWorkshopAttendance)
);

export default router;
