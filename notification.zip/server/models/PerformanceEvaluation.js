import mongoose from 'mongoose';

const performanceEvaluationSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  supervisor: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  evaluationDate: {
    type: Date,
    required: true
  },
  metrics: [{
    name: {
      type: String,
      required: true
    },
    rating: {
      type: Number,
      min: 1,
      max: 5,
      required: true
    },
    comments: String
  }],
  overallRating: {
    type: Number,
    min: 1,
    max: 5
  },
  overallComments: String
}, {
  timestamps: true
});

export default mongoose.model('PerformanceEvaluation', performanceEvaluationSchema);
