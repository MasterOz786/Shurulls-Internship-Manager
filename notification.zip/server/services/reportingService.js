import mongoose from 'mongoose';
import nodemailer from 'nodemailer';
import Task from '../models/Task.js';
import User from '../models/User.js';
import Attendance from '../models/Attendance.js';
import Workshop from '../models/Workshop.js';
import Resource from '../models/Resource.js';

// Configure email transporter
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: process.env.SMTP_PORT,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS
  }
});

export class ReportingService {
  static async generateWeeklySupervisorReport(departmentId) {
    // Aggregate tasks
    const taskReport = await Task.aggregate([
      { $match: { department: mongoose.Types.ObjectId(departmentId) } },
      {
        $group: {
          _id: '$status',
          count: { $sum: 1 },
          tasks: { 
            $push: { 
              title: '$title', 
              assignedTo: '$assignedTo', 
              deadline: '$deadline' 
            } 
          }
        }
      }
    ]);

    // Attendance summary
    const attendanceReport = await Attendance.aggregate([
      { 
        $match: { 
          department: mongoose.Types.ObjectId(departmentId),
          date: { 
            $gte: new Date(new Date().setDate(new Date().getDate() - 7)) 
          } 
        } 
      },
      {
        $group: {
          _id: '$status',
          count: { $sum: 1 }
        }
      }
    ]);

    // Resource utilization
    const resourceReport = await Resource.aggregate([
      { $match: { department: mongoose.Types.ObjectId(departmentId) } },
      {
        $group: {
          _id: '$status',
          count: { $sum: 1 }
        }
      }
    ]);

    return {
      tasks: taskReport,
      attendance: attendanceReport,
      resources: resourceReport
    };
  }

  static async sendWeeklySupervisorReports() {
    // Get all departments
    const departments = await Department.find();

    for (let department of departments) {
      // Generate report
      const report = await this.generateWeeklySupervisorReport(department._id);

      // Find supervisors for this department
      const supervisors = await User.find({ 
        department: department._id, 
        role: 'supervisor' 
      });

      // Send email to each supervisor
      for (let supervisor of supervisors) {
        await this.sendWeeklyReportEmail(supervisor, department, report);
      }
    }
  }

  static async sendWeeklyReportEmail(supervisor, department, report) {
    const emailHtml = this.generateReportEmailTemplate(department, report);

    await transporter.sendMail({
      from: process.env.EMAIL_FROM,
      to: supervisor.email,
      subject: `Weekly Department Report - ${department.name}`,
      html: emailHtml
    });
  }

  static generateReportEmailTemplate(department, report) {
    return `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h1>Weekly Department Report: ${department.name}</h1>
        
        <h2>Task Summary</h2>
        <table border="1" style="width: 100%; border-collapse: collapse;">
          <tr>
            <th>Status</th>
            <th>Count</th>
          </tr>
          ${report.tasks.map(task => `
            <tr>
              <td>${task._id}</td>
              <td>${task.count}</td>
            </tr>
          `).join('')}
        </table>

        <h2>Attendance Summary</h2>
        <table border="1" style="width: 100%; border-collapse: collapse;">
          <tr>
            <th>Status</th>
            <th>Count</th>
          </tr>
          ${report.attendance.map(att => `
            <tr>
              <td>${att._id}</td>
              <td>${att.count}</td>
            </tr>
          `).join('')}
        </table>

        <h2>Resource Utilization</h2>
        <table border="1" style="width: 100%; border-collapse: collapse;">
          <tr>
            <th>Status</th>
            <th>Count</th>
          </tr>
          ${report.resources.map(res => `
            <tr>
              <td>${res._id}</td>
              <td>${res.count}</td>
            </tr>
          `).join('')}
        </table>
      </div>
    `;
  }
}

// Scheduled job to run weekly
export const scheduleWeeklyReports = () => {
  // Use node-cron or similar to schedule this
  // This would run every Sunday at midnight
  cron.schedule('0 0 * * 0', () => {
    ReportingService.sendWeeklySupervisorReports();
  });
};
