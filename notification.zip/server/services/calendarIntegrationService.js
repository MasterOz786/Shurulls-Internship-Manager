import { google } from 'googleapis';
import { OAuth2Client } from 'google-auth-library';

class CalendarIntegrationService {
  constructor() {
    this.oauth2Client = new OAuth2Client(
      process.env.GOOGLE_CLIENT_ID,
      process.env.GOOGLE_CLIENT_SECRET,
      process.env.GOOGLE_REDIRECT_URL
    );
  }

  // Generate Google OAuth consent URL
  generateAuthUrl() {
    const scopes = [
      'https://www.googleapis.com/auth/calendar.events'
    ];

    return this.oauth2Client.generateAuthUrl({
      access_type: 'offline',
      scope: scopes
    });
  }

  // Exchange authorization code for tokens
  async getTokens(code) {
    const { tokens } = await this.oauth2Client.getToken(code);
    this.oauth2Client.setCredentials(tokens);
    return tokens;
  }

  // Create a calendar event
  async createEvent(userId, eventDetails) {
    // Fetch user's calendar credentials from database
    const userCalendarCredentials = await UserCalendarCredential.findOne({ 
      user: userId 
    });

    if (!userCalendarCredentials) {
      throw new Error('No calendar credentials found');
    }

    this.oauth2Client.setCredentials(userCalendarCredentials.tokens);

    const calendar = google.calendar({ version: 'v3', auth: this.oauth2Client });

    const event = {
      summary: eventDetails.title,
      description: eventDetails.description,
      start: {
        dateTime: eventDetails.startTime,
        timeZone: 'UTC'
      },
      end: {
        dateTime: eventDetails.endTime,
        timeZone: 'UTC'
      }
    };

    const response = await calendar.events.insert({
      calendarId: 'primary',
      resource: event
    });

    return response.data;
  }

  // Sync tasks to calendar
  async syncTasksToCalendar(userId, tasks) {
    for (let task of tasks) {
      await this.createEvent(userId, {
        title: task.title,
        description: task.description,
        startTime: task.startDate,
        endTime: task.deadline
      });
    }
  }
}

export default new CalendarIntegrationService();
