import PerformanceEvaluation from '../models/PerformanceEvaluation.js';
import { catchAsync } from '../utils/catchAsync.js';
import { NotFoundError } from '../utils/errors.js';

export const createEvaluation = catchAsync(async (req, res) => {
  const evaluation = await PerformanceEvaluation.create({
    ...req.body,
    supervisor: req.user.id
  });
  res.status(201).json(evaluation);
});

export const getEvaluations = catchAsync(async (req, res) => {
  const { userId } = req.params;
  const evaluations = await PerformanceEvaluation.find({ user: userId })
    .populate('user', 'name')
    .populate('supervisor', 'name')
    .populate('department', 'name');
  if (!evaluations) throw new NotFoundError('Evaluations not found');
  res.json(evaluations);
});

export const getSummary = catchAsync(async (req, res) => {
  const { departmentId } = req.params;
  const summary = await PerformanceEvaluation.aggregate([
    { $match: { department: departmentId } },
    {
      $group: {
        _id: '$user',
        averageRating: { $avg: '$overallRating' },
        evaluations: { $push: '$$ROOT' }
      }
    },
    {
      $lookup: {
        from: 'users',
        localField: '_id',
        foreignField: '_id',
        as: 'userDetails'
      }
    },
    { $unwind: '$userDetails' }
  ]);
  res.json(summary);
});
