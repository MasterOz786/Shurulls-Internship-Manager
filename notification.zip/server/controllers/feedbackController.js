import Feedback from '../models/Feedback.js';
import { sendNotification } from '../services/notificationService.js';

export const createFeedback = async (req, res) => {
  const { 
    task, 
    to, 
    type, 
    content, 
    rating 
  } = req.body;
  const from = req.user._id;

  const feedback = new Feedback({
    task,
    from,
    to,
    type,
    content,
    rating
  });

  await feedback.save();

  // Notify the recipient about new feedback
  await sendNotification(to, {
    type: 'feedback_received',
    message: `New ${type} received`,
    link: `/feedback/${feedback._id}`
  });

  res.status(201).json(feedback);
};

export const getFeedbackForUser = async (req, res) => {
  const userId = req.user._id;
  const { type } = req.query;

  const query = { 
    $or: [
      { from: userId },
      { to: userId }
    ]
  };

  if (type) query.type = type;

  const feedback = await Feedback.find(query)
    .populate('task')
    .populate('from', 'name')
    .populate('to', 'name')
    .sort({ createdAt: -1 });

  res.json(feedback);
};

export const resolveFeedback = async (req, res) => {
  const { feedbackId } = req.params;
  const { status } = req.body;

  const feedback = await Feedback.findByIdAndUpdate(
    feedbackId, 
    { status }, 
    { new: true }
  );

  // Notify the original sender about feedback resolution
  await sendNotification(feedback.from, {
    type: 'feedback_resolved',
    message: `Feedback has been ${status}`,
    link: `/feedback/${feedbackId}`
  });

  res.json(feedback);
};

export const createEndOfInternshipFeedback = async (req, res) => {
  const { 
    interneeId, 
    supervisorId, 
    content, 
    rating 
  } = req.body;

  const feedback = new Feedback({
    type: 'end_of_internship',
    from: req.user._id,
    to: interneeId === req.user._id ? supervisorId : interneeId,
    content,
    rating
  });

  await feedback.save();

  // Notify the recipient about end of internship feedback
  await sendNotification(feedback.to, {
    type: 'end_of_internship_feedback',
    message: 'End of internship feedback received',
    link: `/feedback/${feedback._id}`
  });

  res.status(201).json(feedback);
};
