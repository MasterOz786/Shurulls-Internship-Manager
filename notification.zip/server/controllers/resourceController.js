import Resource from '../models/Resource.js';
import User from '../models/User.js';
import { catchAsync } from '../utils/catchAsync.js';
import { NotFoundError } from '../utils/errors.js';

export const requestResource = catchAsync(async (req, res) => {
  const { resourceType, details } = req.body;
  const resource = await Resource.create({
    type: resourceType,
    details,
    requestedBy: req.user.id,
    status: 'pending'
  });

  res.status(201).json(resource);
});

export const getInterneeResources = catchAsync(async (req, res) => {
  const resources = await Resource.find({ 
    $or: [
      { assignedTo: req.user.id },
      { requestedBy: req.user.id }
    ]
  }).populate('assignedTo', 'name email');

  res.json(resources);
});

export const getAllResourceRequests = catchAsync(async (req, res) => {
  const resources = await Resource.find()
    .populate('requestedBy', 'name email')
    .populate('assignedTo', 'name email');

  res.json(resources);
});

export const updateResourceStatus = catchAsync(async (req, res) => {
  const { status, assignedTo } = req.body;
  const resource = await Resource.findByIdAndUpdate(
    req.params.id, 
    { 
      status, 
      ...(assignedTo && { assignedTo }),
      updatedAt: new Date() 
    }, 
    { new: true }
  );

  if (!resource) {
    throw new NotFoundError('Resource not found');
  }

  res.json(resource);
});

export const returnResource = catchAsync(async (req, res) => {
  const resource = await Resource.findByIdAndUpdate(
    req.params.id,
    { 
      status: 'available', 
      assignedTo: null,
      returnedAt: new Date() 
    },
    { new: true }
  );

  if (!resource) {
    throw new NotFoundError('Resource not found');
  }

  res.json(resource);
});
