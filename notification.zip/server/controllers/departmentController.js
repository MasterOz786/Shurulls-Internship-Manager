import Department from '../models/Department.js';
import User from '../models/User.js';
import { catchAsync } from '../utils/catchAsync.js';
import { NotFoundError } from '../utils/errors.js';

export const createDepartment = catchAsync(async (req, res) => {
  const department = await Department.create(req.body);
  res.status(201).json(department);
});

export const getAllDepartments = catchAsync(async (req, res) => {
  const departments = await Department.find().populate('head', 'name email');
  res.json(departments);
});

export const getDepartment = catchAsync(async (req, res) => {
  const department = await Department.findById(req.params.id)
    .populate('head', 'name email')
    .populate('internees', 'name email');
  if (!department) throw new NotFoundError('Department not found');
  res.json(department);
});

export const updateDepartment = catchAsync(async (req, res) => {
  const department = await Department.findByIdAndUpdate(req.params.id, req.body, { new: true });
  if (!department) throw new NotFoundError('Department not found');
  res.json(department);
});

export const deleteDepartment = catchAsync(async (req, res) => {
  const department = await Department.findByIdAndDelete(req.params.id);
  if (!department) throw new NotFoundError('Department not found');
  res.status(204).end();
});

export const assignInternee = catchAsync(async (req, res) => {
  const { interneeId } = req.body;
  const department = await Department.findById(req.params.id);
  if (!department) throw new NotFoundError('Department not found');

  const internee = await User.findById(interneeId);
  if (!internee) throw new NotFoundError('Internee not found');

  if (internee.role !== 'internee') {
    throw new Error('User is not an internee');
  }

  if (!department.internees.includes(interneeId)) {
    department.internees.push(interneeId);
    await department.save();
  }

  res.json(department);
});

export const removeInternee = catchAsync(async (req, res) => {
  const { interneeId } = req.body;
  const department = await Department.findById(req.params.id);
  if (!department) throw new NotFoundError('Department not found');

  department.internees = department.internees.filter(id => id.toString() !== interneeId);
  await department.save();

  res.json(department);
});
