import { AuthService } from '../services/authService.js';
import { catchAsync } from '../utils/catchAsync.js';
import { DuplicateError, ValidationError } from '../utils/errors.js';

export const login = catchAsync(async (req, res) => {
  const { email, password } = req.body;
  const { user, token } = await AuthService.login(email, password);
  
  res.cookie('token', token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production', // Updated: secure only in production
    sameSite: 'strict',
    maxAge: 24 * 60 * 60 * 1000 // 24 hours
  });

  res.json({ user });
});

export const register = catchAsync(async (req, res) => {
  try {
    const { user, token } = await AuthService.register(req.body);
    
    res.cookie('token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production', // Updated: secure only in production
      sameSite: 'strict',
      maxAge: 24 * 60 * 60 * 1000
    });

    res.status(201).json({ user });
  } catch (error) {
    if (error instanceof DuplicateError) {
      res.status(409).json({ message: error.message });
      return;
    } else if (error instanceof ValidationError) {
      res.status(400).json({ message: error.message });
      return;
    } else {
      res.status(500).json({ message: 'An error occurred while registering the user.' });
      return;
    }
  }
});

export const logout = catchAsync(async (req, res) => {
  res.clearCookie('token');
  res.json({ message: 'Logged out successfully' });
});

export const getSession = catchAsync(async (req, res, next) => {
  const token = req.cookies.token;
  if (!token) {
    return res.status(401).json({ message: 'Authentication required' });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await AuthService.validateSession(decoded.id);
    res.json({ user: AuthService.createUserResponse(user) });
  } catch (error) {
    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({ message: 'Token expired' });
    } else if (error.name === 'JsonWebTokenError') {
      return res.status(401).json({ message: 'Invalid token' });
    }
    next(error);
  }
});
