import React from 'react';
import { NavLink } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { 
  Users, 
  ClipboardList, 
  Calendar, 
  Settings,
  BookOpen,
  CheckSquare,
  UserCircle,
  Laptop,
  Upload
} from 'lucide-react';

const Sidebar: React.FC = () => {
  const { user } = useAuth();

  const getNavLinks = () => {
    const commonLinks = [
      { to: '/dashboard', icon: <UserCircle size={20} />, text: 'Dashboard' },
      { to: '/profile', icon: <UserCircle size={20} />, text: 'Profile' },
    ];

    const adminLinks = [
      { to: '/users', icon: <Users size={20} />, text: 'Manage Users' },
      { to: '/departments', icon: <BookOpen size={20} />, text: 'Departments' },
      { to: '/system-monitoring', icon: <Settings size={20} />, text: 'System Monitoring' },
      { to: '/resource-management', icon: <Laptop size={20} />, text: 'Resource Management' },
      { to: '/attendance-management', icon: <Calendar size={20} />, text: 'Attendance' },
    ];

    const supervisorLinks = [
      { to: '/tasks', icon: <ClipboardList size={20} />, text: 'Tasks' },
      { to: '/internees', icon: <Users size={20} />, text: 'Internees' },
      { to: '/attendance', icon: <Calendar size={20} />, text: 'Attendance' },
    ];

    const interneeLinks = [
      { to: '/my-tasks', icon: <ClipboardList size={20} />, text: 'My Tasks' },
      { to: '/my-resources', icon: <Laptop size={20} />, text: 'Resources' },
      { to: '/submissions', icon: <Upload size={20} />, text: 'Submissions' },
    ];

    switch (user?.role) {
      case 'admin':
        return [...commonLinks, ...adminLinks];
      case 'supervisor':
        return [...commonLinks, ...supervisorLinks];
      case 'internee':
        return [...commonLinks, ...interneeLinks];
      default:
        return commonLinks;
    }
  };

  return (
    <div className="bg-gray-900 text-white w-64 space-y-6 py-7 px-2 absolute inset-y-0 left-0 transform -translate-x-full md:relative md:translate-x-0 transition duration-200 ease-in-out">
      <div className="flex items-center justify-center">
        <h1 className="text-xl font-bold">IMS Dashboard</h1>
      </div>
      
      <nav className="mt-10">
        {getNavLinks().map((link) => (
          <NavLink
            key={link.to}
            to={link.to}
            className={({ isActive }) =>
              `flex items-center py-2 px-4 rounded transition-colors duration-200 ${
                isActive 
                  ? 'bg-gray-800 text-white' 
                  : 'text-gray-400 hover:bg-gray-800 hover:text-white'
              }`
            }
          >
            {link.icon}
            <span className="mx-4">{link.text}</span>
          </NavLink>
        ))}
      </nav>
    </div>
  );
};

export default Sidebar;
