import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import DashboardLayout from './components/Layout/DashboardLayout';
import Login from './pages/auth/Login';
import Signup from './pages/auth/Signup';
import AdminDashboard from './pages/dashboard/AdminDashboard';
import SupervisorDashboard from './pages/dashboard/SupervisorDashboard';
import InterneeDashboard from './pages/dashboard/InterneeDashboard';
import Profile from './pages/Profile';
import MyTasks from './pages/internee/MyTasks';
import MyResources from './pages/internee/MyResources';
import Submissions from './pages/internee/Submissions';

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          
          <Route path="/" element={<DashboardLayout />}>
            <Route index element={<Navigate to="/dashboard" replace />} />
            <Route path="dashboard" element={<DashboardRouter />} />
            <Route path="profile" element={<Profile />} />
            <Route path="my-tasks" element={<MyTasks />} />
            <Route path="my-resources" element={<MyResources />} />
            <Route path="submissions" element={<Submissions />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}

const DashboardRouter = () => {
  const { user } = useAuth();

  switch (user?.role) {
    case 'admin':
      return <AdminDashboard />;
    case 'supervisor':
      return <SupervisorDashboard />;
    case 'internee':
      return <InterneeDashboard />;
    default:
      return <Navigate to="/login" replace />;
  }
};

export default App;
