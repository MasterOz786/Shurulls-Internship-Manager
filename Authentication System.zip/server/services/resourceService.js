import Resource from '../models/Resource.js';
import { NotFoundError } from '../utils/errors.js';

export class ResourceService {
  static async getAllResources() {
    return await Resource.find().populate('currentAllocation.user');
  }

  static async getResourcesByType(type) {
    return await Resource.find({ type });
  }

  static async allocateResource(resourceId, userId, startDate, endDate) {
    const resource = await Resource.findById(resourceId);
    if (!resource) {
      throw new NotFoundError('Resource not found');
    }

    if (resource.status !== 'available') {
      throw new Error('Resource is not available');
    }

    resource.status = 'allocated';
    resource.currentAllocation = {
      user: userId,
      startDate,
      endDate
    };

    return await resource.save();
  }

  static async releaseResource(resourceId) {
    const resource = await Resource.findById(resourceId);
    if (!resource) {
      throw new NotFoundError('Resource not found');
    }

    resource.status = 'available';
    resource.currentAllocation = null;

    return await resource.save();
  }

  static async getResourceUtilization(type, startDate, endDate) {
    const resources = await Resource.find({
      type,
      'currentAllocation.startDate': { $gte: startDate },
      'currentAllocation.endDate': { $lte: endDate }
    });

    return {
      total: await Resource.countDocuments({ type }),
      allocated: resources.length,
      utilization: resources.length / await Resource.countDocuments({ type }) * 100
    };
  }
}
