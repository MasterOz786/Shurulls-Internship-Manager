import express from 'express';
import { verifyToken, requireRole } from '../middleware/auth.js';
import * as resourceController from '../controllers/resourceController.js';

const router = express.Router();

// Internee routes
router.post('/request', verifyToken, resourceController.requestResource);
router.get('/my-resources', verifyToken, resourceController.getInterneeResources);

// Supervisor/Admin routes
router.get('/', verifyToken, requireRole('supervisor', 'admin'), resourceController.getAllResourceRequests);
router.put('/:id/status', verifyToken, requireRole('supervisor', 'admin'), resourceController.updateResourceStatus);
router.put('/:id/return', verifyToken, resourceController.returnResource);

export default router;
