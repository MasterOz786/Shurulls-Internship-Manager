import express from 'express';
import { verifyToken, requireRole } from '../middleware/auth.js';
import * as departmentController from '../controllers/departmentController.js';

const router = express.Router();

router.post('/', verifyToken, requireRole('admin'), departmentController.createDepartment);
router.get('/', verifyToken, departmentController.getAllDepartments);
router.get('/:id', verifyToken, departmentController.getDepartment);
router.put('/:id', verifyToken, requireRole('admin'), departmentController.updateDepartment);
router.delete('/:id', verifyToken, requireRole('admin'), departmentController.deleteDepartment);
router.post('/:id/assign', verifyToken, requireRole('admin', 'supervisor'), departmentController.assignInternee);
router.post('/:id/remove', verifyToken, requireRole('admin', 'supervisor'), departmentController.removeInternee);

export default router;
