import Attendance from '../models/Attendance.js';
import User from '../models/User.js';
import { catchAsync } from '../utils/catchAsync.js';
import { NotFoundError } from '../utils/errors.js';

export const checkIn = catchAsync(async (req, res) => {
  const userId = req.user.id;
  const date = new Date();
  const existingAttendance = await Attendance.findOne({ user: userId, date });
  if (existingAttendance) {
    return res.status(400).json({ message: 'Already checked in today' });
  }
  const attendance = await Attendance.create({ user: userId, date, checkInTime: new Date(), status: 'present' });
  res.status(201).json(attendance);
});

export const checkOut = catchAsync(async (req, res) => {
  const userId = req.user.id;
  const date = new Date();
  const attendance = await Attendance.findOne({ user: userId, date });
  if (!attendance) {
    return res.status(404).json({ message: 'No check-in record found' });
  }
  if (attendance.checkOutTime) {
    return res.status(400).json({ message: 'Already checked out today' });
  }
  attendance.checkOutTime = new Date();
  await attendance.save();
  res.json(attendance);
});

export const getAttendance = catchAsync(async (req, res) => {
  const { startDate, endDate, department } = req.query;
  const filter = {};
  if (startDate && endDate) {
    filter.date = { $gte: new Date(startDate), $lte: new Date(endDate) };
  }
  if (department) {
    filter.department = department;
  }
  const attendance = await Attendance.find(filter).populate('user', 'name email');
  res.json(attendance);
});

export const getAttendanceSummary = catchAsync(async (req, res) => {
  const { startDate, endDate, department } = req.query;
  const filter = {};
  if (startDate && endDate) {
    filter.date = { $gte: new Date(startDate), $lte: new Date(endDate) };
  }
  if (department) {
    filter.department = department;
  }
  const summary = await Attendance.aggregate([
    { $match: filter },
    {
      $group: {
        _id: '$user',
        totalPresent: { $sum: { $cond: [{ $eq: ['$status', 'present'] }, 1, 0] } },
        totalAbsent: { $sum: { $cond: [{ $eq: ['$status', 'absent'] }, 1, 0] } },
        totalLate: { $sum: { $cond: [{ $eq: ['$status', 'late'] }, 1, 0] } }
      }
    },
    {
      $lookup: {
        from: 'users',
        localField: '_id',
        foreignField: '_id',
        as: 'userDetails'
      }
    },
    { $unwind: '$userDetails' }
  ]);
  res.json(summary);
});
