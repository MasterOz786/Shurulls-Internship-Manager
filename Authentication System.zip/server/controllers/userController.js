import User from '../models/User.js';
import { catchAsync } from '../utils/catchAsync.js';
import { NotFoundError, ValidationError } from '../utils/errors.js';

export const updateUserProfile = catchAsync(async (req, res) => {
  const userId = req.params.id;
  const updates = req.body;

  // Check if user is updating their own profile
  if (req.user.id !== userId && req.user.role !== 'admin') {
    return res.status(403).json({ message: 'Unauthorized to update this profile' });
  }

  const user = await User.findByIdAndUpdate(userId, updates, { new: true, runValidators: true });

  if (!user) {
    throw new NotFoundError('User not found');
  }

  res.json({ message: 'Profile updated successfully', user });
});
