import mongoose from 'mongoose';

const resourceSchema = new mongoose.Schema({
  type: {
    type: String,
    required: true,
    enum: ['workstation', 'laptop', 'id_card', 'auditorium_access']
  },
  identifier: {
    type: String,
    required: true,
    unique: true
  },
  details: {
    type: Map,
    of: String
  },
  assignedTo: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  status: {
    type: String,
    enum: ['available', 'assigned', 'maintenance'],
    default: 'available'
  }
}, {
  timestamps: true
});

export default mongoose.model('Resource', resourceSchema);
