import React, { useState, useEffect } from 'react';
import { Bell } from 'lucide-react';

interface Notification {
  _id: string;
  type: string;
  message: string;
  link?: string;
  isRead: boolean;
  createdAt: string;
}

const Notifications: React.FC = () => {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    fetchNotifications();
  }, []);

  const fetchNotifications = async () => {
    try {
      const response = await fetch('/api/notifications');
      const data = await response.json();
      setNotifications(data);
      setUnreadCount(data.filter((n: Notification) => !n.isRead).length);
    } catch (error) {
      console.error('Failed to fetch notifications', error);
    }
  };

  const markAsRead = async (notificationId: string) => {
    try {
      await fetch(`/api/notifications/${notificationId}/read`, { method: 'PUT' });
      fetchNotifications();
    } catch (error) {
      console.error('Failed to mark notification as read', error);
    }
  };

  const getNotificationIcon = (type: string) => {
    const icons = {
      'workshop_created': '📅',
      'workshop_registration': '✅',
      'task_assigned': '📋',
      'task_deadline_approaching': '⏰',
      'certificate_pending': '📜',
      'certificate_approved': '🏆'
    };
    return icons[type] || '🔔';
  };

  return (
    <div className="relative">
      <div className="relative">
        <Bell className="h-6 w-6 text-gray-600" />
        {unreadCount > 0 && (
          <span className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full px-2 py-1 text-xs">
            {unreadCount}
          </span>
        )}
      </div>

      <div className="absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-lg z-50">
        <div className="p-4 border-b">
          <h3 className="text-lg font-semibold">Notifications</h3>
        </div>
        {notifications.length === 0 ? (
          <div className="p-4 text-center text-gray-500">
            No notifications
          </div>
        ) : (
          <div className="max-h-96 overflow-y-auto">
            {notifications.map((notification) => (
              <div 
                key={notification._id} 
                className={`p-4 border-b flex items-center ${
                  !notification.isRead ? 'bg-blue-50' : 'bg-white'
                }`}
              >
                <span className="mr-3 text-2xl">
                  {getNotificationIcon(notification.type)}
                </span>
                <div className="flex-grow">
                  <p className="text-sm">{notification.message}</p>
                  <p className="text-xs text-gray-500">
                    {new Date(notification.createdAt).toLocaleString()}
                  </p>
                </div>
                {!notification.isRead && (
                  <button 
                    onClick={() => markAsRead(notification._id)}
                    className="text-xs text-blue-500 hover:text-blue-700"
                  >
                    Mark as Read
                  </button>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Notifications;
