import React from 'react';
import { useAuth } from '../../context/AuthContext';
import { Navigate, Outlet } from 'react-router-dom';
import Sidebar from './Sidebar';
import Header from './Header';
import {
  LayoutDashboard,
  Users,
  BookOpen,
  Settings,
  Activity,
  Server,
  Database,
  AlertTriangle,
  ClipboardList,
  Calendar,
  UserCircle,
  Laptop,
  Upload,
  CheckSquare,
  MessageCircle,
  FileText,
  QrCode,
  LogIn,
  LogOut,
  Bell,
  Plus,
  Star,
  Send,
  MapPin,
  Clock
} from 'lucide-react';

const DashboardLayout: React.FC = () => {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return <div className="flex items-center justify-center min-h-screen">Loading...</div>;
  }

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-100 p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default DashboardLayout;
