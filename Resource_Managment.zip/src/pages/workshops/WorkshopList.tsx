import React, { useState, useEffect } from 'react';
import { Calendar, MapPin, Users } from 'lucide-react';

interface Workshop {
  _id: string;
  title: string;
  description: string;
  date: string;
  startTime: string;
  endTime: string;
  location: string;
  registeredInternees: string[];
  status: string;
}

const WorkshopList: React.FC = () => {
  const [workshops, setWorkshops] = useState<Workshop[]>([]);
  const [filter, setFilter] = useState('upcoming');

  useEffect(() => {
    fetchWorkshops();
  }, [filter]);

  const fetchWorkshops = async () => {
    try {
      const response = await fetch(`/api/workshops?status=${filter}`);
      const data = await response.json();
      setWorkshops(data);
    } catch (error) {
      console.error('Failed to fetch workshops', error);
    }
  };

  const registerForWorkshop = async (workshopId: string) => {
    try {
      const response = await fetch(`/api/workshops/${workshopId}/register`, {
        method: 'POST'
      });
      const data = await response.json();
      fetchWorkshops();
    } catch (error) {
      console.error('Failed to register for workshop', error);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-semibold text-gray-900">Workshops</h1>
        <div className="space-x-2">
          <button 
            onClick={() => setFilter('upcoming')}
            className={`px-4 py-2 rounded ${
              filter === 'upcoming' 
                ? 'bg-indigo-500 text-white' 
                : 'bg-gray-200 text-gray-800'
            }`}
          >
            Upcoming
          </button>
          <button 
            onClick={() => setFilter('completed')}
            className={`px-4 py-2 rounded ${
              filter === 'completed' 
                ? 'bg-indigo-500 text-white' 
                : 'bg-gray-200 text-gray-800'
            }`}
          >
            Completed
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {workshops.map((workshop) => (
          <div 
            key={workshop._id} 
            className="bg-white shadow rounded-lg p-6 space-y-4"
          >
            <div className="flex justify-between items-center">
              <h2 className="text-lg font-semibold">{workshop.title}</h2>
              <span 
                className={`px-2 py-1 rounded-full text-xs uppercase ${
                  workshop.status === 'upcoming' 
                    ? 'bg-green-100 text-green-800' 
                    : 'bg-gray-100 text-gray-800'
                }`}
              >
                {workshop.status}
              </span>
            </div>

            <p className="text-gray-600 text-sm">{workshop.description}</p>

            <div className="space-y-2">
              <div className="flex items-center text-sm text-gray-500">
                <Calendar className="mr-2 h-4 w-4" />
                {new Date(workshop.date).toLocaleDateString()} | {workshop.startTime} - {workshop.endTime}
              </div>
              <div className="flex items-center text-sm text-gray-500">
                <MapPin className="mr-2 h-4 w-4" />
                {workshop.location}
              </div>
              <div className="flex items-center text-sm text-gray-500">
                <Users className="mr-2 h-4 w-4" />
                {workshop.registeredInternees.length} Registered
              </div>
            </div>

            {workshop.status === 'upcoming' && (
              <button 
                onClick={() => registerForWorkshop(workshop._id)}
                className="w-full bg-indigo-500 text-white py-2 rounded-md hover:bg-indigo-600"
              >
                Register
              </button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default WorkshopList;
