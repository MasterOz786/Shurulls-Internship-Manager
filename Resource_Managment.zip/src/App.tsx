import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import DashboardLayout from './components/Layout/DashboardLayout';
import Login from './pages/auth/Login';
import Signup from './pages/auth/Signup';
import AdminDashboard from './pages/dashboard/AdminDashboard';
import SupervisorDashboard from './pages/dashboard/SupervisorDashboard';
import InterneeDashboard from './pages/dashboard/InterneeDashboard';
import Profile from './pages/Profile';
import MyTasks from './pages/internee/MyTasks';
import MyResources from './pages/internee/MyResources';
import Submissions from './pages/internee/Submissions';
import WorkshopList from './pages/workshops/WorkshopList';
import CertificateList from './pages/certificates/CertificateList';
import FeedbackList from './pages/feedback/FeedbackList';
import FeedbackForm from './pages/feedback/FeedbackForm';
import Notifications from './components/Notifications';
import Departments from './pages/admin/Departments';
import Users from './pages/admin/Users';
import SystemMonitoring from './pages/admin/SystemMonitoring';
import ResourceManagement from './pages/admin/ResourceManagement';
import AttendanceManagement from './pages/admin/AttendanceManagement';
import PerformanceEvaluation from './pages/supervisor/PerformanceEvaluation';
import { useEffect, useState } from 'react';
import { Loader2 } from 'lucide-react';


function App() {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const response = await fetch('http://localhost:3000/api/auth/session', {
          method: 'GET',
          credentials: 'include'
        });
        if (!response.ok) {
          setIsLoading(false);
          return;
        }
        setIsLoading(false);
      } catch (error) {
        console.error("Error checking authentication:", error);
        setIsLoading(false);
      }
    };
    checkAuth();
  }, []);

  return (
    <AuthProvider>
      {isLoading ? (
        <div className="flex justify-center items-center h-screen">
          <Loader2 className="animate-spin h-12 w-12 text-indigo-500" />
        </div>
      ) : (
        <BrowserRouter>
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<Signup />} />

            <Route path="/" element={<DashboardLayout />}>
              <Route index element={<Navigate to="/dashboard" replace />} />
              <Route path="dashboard" element={<DashboardRouter />} />
              <Route path="profile" element={<Profile />} />
              <Route path="my-tasks" element={<MyTasks />} />
              <Route path="my-resources" element={<MyResources />} />
              <Route path="submissions" element={<Submissions />} />
              <Route path="workshops" element={<WorkshopList />} />
              <Route path="certificates" element={<CertificateList />} />
              <Route path="feedback" element={<FeedbackList />} />
              <Route path="feedback/task/:taskId" element={<TaskFeedbackForm />} />
              <Route path="feedback/clarification/:taskId" element={<ClarificationRequestForm />} />
              <Route path="notifications" element={<Notifications />} />
              <Route path="admin/*" element={<AdminRoutes />} />
              <Route path="supervisor/*" element={<SupervisorRoutes />} />
            </Route>
          </Routes>
        </BrowserRouter>
      )}
    </AuthProvider>
  );
}

const DashboardRouter = () => {
  const { user } = useAuth();

  switch (user?.role) {
    case 'admin':
      return <AdminDashboard />;
    case 'supervisor':
      return <SupervisorDashboard />;
    case 'internee':
      return <InterneeDashboard />;
    default:
      return <Navigate to="/login" replace />;
  }
};

const AdminRoutes = () => {
  const { user } = useAuth();
  if (!user || user.role !== 'admin') {
    return <Navigate to="/login" replace />;
  }
  return (
    <>
      <Route path="departments" element={<Departments />} />
      <Route path="users" element={<Users />} />
      <Route path="system-monitoring" element={<SystemMonitoring />} />
      <Route path="resource-management" element={<ResourceManagement />} />
      <Route path="attendance-management" element={<AttendanceManagement />} />
    </>
  );
};

const SupervisorRoutes = () => {
  const { user } = useAuth();
  if (!user || user.role !== 'supervisor') {
    return <Navigate to="/login" replace />;
  }
  return (
    <>
      <Route path="performance-evaluation" element={<PerformanceEvaluation />} />
    </>
  );
};

const TaskFeedbackForm: React.FC = () => {
  // ... (rest of the component)
};

const ClarificationRequestForm: React.FC = () => {
  // ... (rest of the component)
};

export default App;
