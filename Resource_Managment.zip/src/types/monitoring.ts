export interface ServerStatus {
  cpuUsage: number;
  memoryUsage: number;
  uptime: number;
  activeConnections: number;
  databaseStatus: 'healthy' | 'degraded' | 'down';
  lastIncident: string | null;
}

export interface SystemLog {
  id: string;
  timestamp: Date;
  level: 'info' | 'warning' | 'error';
  message: string;
  source: string;
}

export interface ResourceAllocation {
  id: string;
  resourceType: string;
  resourceId: string;
  assignedTo: string;
  status: 'active' | 'pending' | 'completed';
  startDate: Date;
  endDate?: Date;
}
